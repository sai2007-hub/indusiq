import React from 'react';
import { useApp } from '../context/AppContext';
import { ProductAttribute } from '../types';
import {
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  FileText,
  Globe,
  BookOpen,
  Sparkles,
  Download,
  ArrowRight,
  HelpCircle,
  ExternalLink,
  History,
  Tag,
  Zap,
} from 'lucide-react';

export const ProductIntelligencePage: React.FC = () => {
  const {
    activeProduct,
    openEvidenceDrawer,
    setCurrentPage,
    totalConflictsCount,
  } = useApp();

  if (!activeProduct) {
    return (
      <div className="p-12 text-center bg-white rounded-3xl border border-slate-200">
        <p className="text-slate-500">No product selected.</p>
      </div>
    );
  }

  const attributes: ProductAttribute[] = Object.values(activeProduct.attributes);
  const activeConflicts = activeProduct.conflicts.filter((c) => !c.isResolved);
  const hasConflict = activeConflicts.length > 0;
  const isReadyForCatalog = activeProduct.status === 'READY_FOR_CATALOG';

  return (
    <div className="space-y-8 pb-16">
      {/* Product Banner Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <span className="text-xs font-mono font-bold text-slate-500 uppercase">
              Model: {activeProduct.modelNumber}
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-xs font-semibold text-slate-600">
              SKU: {activeProduct.sku}
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-xs font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-100">
              {activeProduct.category}
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            {activeProduct.name}
          </h1>

          <p className="text-xs text-slate-500 mt-1">
            Manufacturer: <strong className="text-slate-800">{activeProduct.manufacturer}</strong> • Ingested from 3 independent sources • Last updated {activeProduct.lastUpdated.slice(0, 10)}
          </p>
        </div>

        {/* Status Badge & Export Action */}
        <div className="flex flex-wrap items-center gap-3">
          {hasConflict ? (
            <div className="px-4 py-2 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 flex items-center gap-2 text-xs font-bold shadow-xs">
              <AlertTriangle className="w-4 h-4 text-rose-600 animate-pulse" />
              <span>⚠ CONFLICT DETECTED</span>
            </div>
          ) : (
            <div className="px-4 py-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-2 text-xs font-bold shadow-xs">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>✓ READY FOR CATALOG</span>
            </div>
          )}

          <button
            onClick={() => setCurrentPage('exports')}
            className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-colors cursor-pointer inline-flex items-center gap-1.5 border border-slate-200"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Verified (JSON/CSV)</span>
          </button>
        </div>
      </div>

      {/* Trust Score & Four-Factor Breakdown Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 text-white shadow-xl border border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-slate-800 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Explainable Trust Score</span>
                <span className="text-[10px] font-mono bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded border border-blue-500/30">
                  ISO / IEC Verified Formula
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {activeProduct.trustScore.formulaExplanation}
              </p>
            </div>
          </div>

          <div className="flex items-baseline gap-2">
            <span
              className={`text-4xl sm:text-5xl font-black font-mono tracking-tight ${
                activeProduct.trustScore.overall >= 95
                  ? 'text-emerald-400'
                  : 'text-blue-400'
              }`}
            >
              {activeProduct.trustScore.overall}%
            </span>
            <span className="text-xs font-mono text-slate-400">/ 100</span>
          </div>
        </div>

        {/* 4 Factor Meters */}
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Completeness */}
          <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="flex items-center justify-between text-xs text-slate-300 mb-1.5">
              <span className="font-semibold">Completeness (25%)</span>
              <span className="font-mono font-bold text-white">{activeProduct.trustScore.completeness}%</span>
            </div>
            <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
              <div className="bg-blue-500 h-full" style={{ width: `${activeProduct.trustScore.completeness}%` }} />
            </div>
            <p className="text-[10px] text-slate-400 mt-1.5">6 of 7 schema specs present</p>
          </div>

          {/* Consistency */}
          <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="flex items-center justify-between text-xs text-slate-300 mb-1.5">
              <span className="font-semibold">Consistency (40%)</span>
              <span className="font-mono font-bold text-white">{activeProduct.trustScore.consistency}%</span>
            </div>
            <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
              <div
                className={`h-full ${
                  activeProduct.trustScore.consistency < 90 ? 'bg-amber-400' : 'bg-emerald-500'
                }`}
                style={{ width: `${activeProduct.trustScore.consistency}%` }}
              />
            </div>
            <p className="text-[10px] text-slate-400 mt-1.5">
              {hasConflict ? '1 conflicting power rating' : 'Zero multi-source conflicts'}
            </p>
          </div>

          {/* Source Quality */}
          <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="flex items-center justify-between text-xs text-slate-300 mb-1.5">
              <span className="font-semibold">Source Quality (20%)</span>
              <span className="font-mono font-bold text-white">{activeProduct.trustScore.sourceQuality}%</span>
            </div>
            <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
              <div className="bg-indigo-400 h-full" style={{ width: `${activeProduct.trustScore.sourceQuality}%` }} />
            </div>
            <p className="text-[10px] text-slate-400 mt-1.5">Certified Engineering Datasheet (98%)</p>
          </div>

          {/* Extraction Confidence */}
          <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="flex items-center justify-between text-xs text-slate-300 mb-1.5">
              <span className="font-semibold">Extraction Conf. (15%)</span>
              <span className="font-mono font-bold text-white">{activeProduct.trustScore.extractionConfidence}%</span>
            </div>
            <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
              <div className="bg-emerald-400 h-full" style={{ width: `${activeProduct.trustScore.extractionConfidence}%` }} />
            </div>
            <p className="text-[10px] text-slate-400 mt-1.5">High optical & entity match</p>
          </div>
        </div>
      </div>

      {/* Main Specifications Table & Conflict Matrix */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Extracted Product Specifications</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Click on any specification to open the provenance drawer and inspect source citations.
            </p>
          </div>

          {hasConflict && (
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-rose-700 bg-rose-50 px-3 py-1.5 rounded-xl border border-rose-200">
                Action Required: Click Power Rating to resolve
              </span>
            </div>
          )}
        </div>

        {/* Specifications Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-mono font-bold text-slate-500 uppercase tracking-wider">
                <th className="py-3.5 px-6">Specification Attribute</th>
                <th className="py-3.5 px-6">Extracted Value</th>
                <th className="py-3.5 px-6">Multi-Source Verification</th>
                <th className="py-3.5 px-6">Extraction Confidence</th>
                <th className="py-3.5 px-6 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {attributes.map((attr) => {
                const isPower = attr.key === 'power';
                const isEfficiency = attr.key === 'efficiency';

                return (
                  <tr
                    key={attr.key}
                    id={`attr-row-${attr.key}`}
                    onClick={() => openEvidenceDrawer(attr.key)}
                    className={`hover:bg-blue-50/40 transition-colors cursor-pointer ${
                      attr.isConflicted
                        ? 'bg-rose-50/30'
                        : attr.isMissing
                        ? 'bg-amber-50/20'
                        : ''
                    }`}
                  >
                    {/* Attribute Name */}
                    <td className="py-4 px-6">
                      <div className="font-bold text-slate-900 flex items-center gap-2">
                        <span>{attr.name}</span>
                        {attr.standardNormalizedKey && (
                          <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                            {attr.standardNormalizedKey}
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400 capitalize">{attr.category} spec</span>
                    </td>

                    {/* Value */}
                    <td className="py-4 px-6">
                      {attr.isConflicted ? (
                        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-rose-100 text-rose-900 border border-rose-200 font-mono font-bold text-xs">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                          <span>5 HP vs 7.5 HP (Conflict)</span>
                        </div>
                      ) : attr.isMissing ? (
                        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-100 text-amber-900 border border-amber-200 font-mono text-xs">
                          <HelpCircle className="w-3.5 h-3.5 text-amber-600" />
                          <span>Missing (Suggest: IE3 / 89.5%)</span>
                        </div>
                      ) : (
                        <span className="text-sm font-bold font-mono text-slate-900">
                          {attr.value}
                        </span>
                      )}
                    </td>

                    {/* Sources status */}
                    <td className="py-4 px-6">
                      {attr.isConflicted ? (
                        <div className="space-y-1 text-[11px] font-mono">
                          <div className="text-slate-600">
                            • Website: <strong className="text-slate-900">5 HP</strong>
                          </div>
                          <div className="text-slate-600">
                            • Catalog: <strong className="text-slate-900">5 HP</strong>
                          </div>
                          <div className="text-emerald-700 font-bold">
                            • Datasheet Rev 2.4: <strong>7.5 HP (Recommended)</strong>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            {attr.sources.length > 0 ? `${attr.sources.length} Sources Agreed` : 'Verified Spec'}
                          </span>
                        </div>
                      )}
                    </td>

                    {/* Confidence Meter */}
                    <td className="py-4 px-6">
                      {attr.isMissing ? (
                        <span className="text-[11px] font-mono text-slate-400">0% (Unstated)</span>
                      ) : (
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-slate-100 h-1.5 rounded-full overflow-hidden">
                            <div
                              className={`h-full ${
                                attr.confidence >= 95 ? 'bg-emerald-500' : 'bg-blue-500'
                              }`}
                              style={{ width: `${attr.confidence}%` }}
                            />
                          </div>
                          <span className="text-xs font-mono font-bold text-slate-700">
                            {attr.confidence}%
                          </span>
                        </div>
                      )}
                    </td>

                    {/* Action Button */}
                    <td className="py-4 px-6 text-right">
                      {attr.isConflicted ? (
                        <button
                          id="power-conflict-resolve-trigger"
                          onClick={(e) => {
                            e.stopPropagation();
                            openEvidenceDrawer(attr.key);
                          }}
                          className="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer inline-flex items-center gap-1.5"
                        >
                          <span>Resolve</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      ) : attr.isMissing ? (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            openEvidenceDrawer(attr.key);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer inline-flex items-center gap-1"
                        >
                          <Sparkles className="w-3 h-3" />
                          <span>Impute</span>
                        </button>
                      ) : (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            openEvidenceDrawer(attr.key);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-colors cursor-pointer inline-flex items-center gap-1"
                        >
                          <span>Evidence</span>
                          <ExternalLink className="w-3 h-3 text-slate-400" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 2-Column Section: Ingested Provenance Files & Audit Trail */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Ingested Source Documents */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">Ingested Provenance Documents</h3>
              <p className="text-xs text-slate-500 mt-0.5">3 authoritative source files tracked</p>
            </div>
            <button
              onClick={() => setCurrentPage('evidence')}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 cursor-pointer"
            >
              Open Full Matrix →
            </button>
          </div>

          <div className="space-y-3">
            {activeProduct.rawSources.map((src) => {
              const isDatasheet = src.type === 'datasheet';
              const isCatalog = src.type === 'catalog';

              return (
                <div
                  key={src.id}
                  className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-white hover:border-slate-300 transition-colors"
                >
                  <div className="flex items-center justify-between pb-2 border-b border-slate-200/60">
                    <div className="flex items-center gap-2">
                      {isDatasheet ? (
                        <FileText className="w-4 h-4 text-emerald-600" />
                      ) : isCatalog ? (
                        <BookOpen className="w-4 h-4 text-indigo-600" />
                      ) : (
                        <Globe className="w-4 h-4 text-sky-600" />
                      )}
                      <span className="text-xs font-bold text-slate-900">{src.title}</span>
                    </div>
                    <span className="text-[11px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                      Reliability: {Math.round(src.reliabilityWeight * 100)}%
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 font-mono mt-2 bg-white p-2.5 rounded-lg border border-slate-100 leading-relaxed">
                    "{src.contentSnippet}"
                  </p>

                  <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
                    <span>File: {src.fileNameOrUrl}</span>
                    <span>{src.attributeCountExtracted} attributes verified</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Audit Log Trail */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">Immutable Audit History</h3>
              <p className="text-xs text-slate-500 mt-0.5">Chronological record of ingestion & human reviews</p>
            </div>
            <History className="w-4 h-4 text-slate-400" />
          </div>

          <div className="space-y-3">
            {activeProduct.auditHistory.map((audit) => (
              <div
                key={audit.id}
                className="p-3.5 rounded-xl border border-slate-100 bg-slate-50 text-xs space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-slate-900 text-[11px] bg-slate-200/80 px-2 py-0.5 rounded">
                    {audit.action}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {audit.timestamp.slice(11, 19)} UTC
                  </span>
                </div>
                <p className="text-slate-700 text-xs mt-1 leading-relaxed">{audit.details}</p>
                <div className="text-[11px] text-slate-400">
                  Auditor: <span className="font-medium text-slate-600">{audit.user}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
