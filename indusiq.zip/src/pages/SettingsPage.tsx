import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Settings,
  ShieldCheck,
  RotateCcw,
  Zap,
  CheckCircle2,
  Database,
  Cpu,
  Save,
  Key,
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const { resetDemoData, addToast } = useApp();
  const [minConfidenceThreshold, setMinConfidenceThreshold] = useState(85);
  const [autoResolveStandardImputations, setAutoResolveStandardImputations] = useState(true);

  const handleSave = () => {
    addToast('Settings Saved', 'Engine parameters and threshold rules updated.', 'success');
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Engine Configuration & Governance Settings
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Fine-tune ingestion rules, schema standard dictionaries, and local demo environment parameters.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer self-start"
        >
          <Save className="w-4 h-4" />
          <span>Save Settings</span>
        </button>
      </div>

      {/* Demo Mode & Standalone Environment Status */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Standalone Prototype Demo Mode</h2>
              <p className="text-xs text-slate-500">
                100% operational without external API keys or cloud database setup.
              </p>
            </div>
          </div>
          <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
            ACTIVE & FUNCTIONAL
          </span>
        </div>

        <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <p className="text-xs text-slate-600">
            Resetting returns the X500 Industrial Motor back to its initial conflicted state (5 HP vs 7.5 HP) and Trust Score 92%.
          </p>
          <button
            onClick={resetDemoData}
            className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-colors cursor-pointer inline-flex items-center gap-1.5 shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Demo State</span>
          </button>
        </div>
      </div>

      {/* Extraction & Reconciliation Engine Parameters */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-6">
        <div className="flex items-center gap-2">
          <Cpu className="w-5 h-5 text-blue-600" />
          <h2 className="text-lg font-bold text-slate-900">AI Extraction & Conflict Detection Rules</h2>
        </div>

        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h4 className="text-xs font-bold text-slate-900">Minimum Extraction Confidence Floor</h4>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Attributes extracted below this threshold require mandatory human approval.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min="70"
                max="98"
                value={minConfidenceThreshold}
                onChange={(e) => setMinConfidenceThreshold(parseInt(e.target.value))}
                className="w-32 accent-blue-600"
              />
              <span className="text-xs font-mono font-bold text-slate-900 w-10 text-right">
                {minConfidenceThreshold}%
              </span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <div>
              <h4 className="text-xs font-bold text-slate-900">Auto-Suggest Standard Baseline Imputations</h4>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Derive missing parameters using IEC 60034-30 standard tables (e.g. IE3 efficiency class).
              </p>
            </div>
            <input
              type="checkbox"
              checked={autoResolveStandardImputations}
              onChange={(e) => setAutoResolveStandardImputations(e.target.checked)}
              className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Schema Attributes Normalization Dictionary */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4">
        <h2 className="text-lg font-bold text-slate-900">Core Industrial Schema Dictionary</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
          <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 font-mono">
            <span className="text-blue-600 font-bold block">IEC_POWER_KW_HP</span>
            <span className="text-slate-500 text-[11px]">Primary Rated Mechanical Output</span>
          </div>
          <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 font-mono">
            <span className="text-blue-600 font-bold block">IEC_VOLTAGE_AC</span>
            <span className="text-slate-500 text-[11px]">Nominal Line-to-Line Voltage</span>
          </div>
          <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 font-mono">
            <span className="text-blue-600 font-bold block">IEC_ROTOR_SPEED</span>
            <span className="text-slate-500 text-[11px]">Synchronous / Full Load RPM</span>
          </div>
          <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 font-mono">
            <span className="text-blue-600 font-bold block">IEC_60529_IP_CODE</span>
            <span className="text-slate-500 text-[11px]">Enclosure Environmental Rating</span>
          </div>
          <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 font-mono">
            <span className="text-blue-600 font-bold block">IEC_60034_30_EFFICIENCY</span>
            <span className="text-slate-500 text-[11px]">Energy Performance Grade (IE1–IE4)</span>
          </div>
          <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 font-mono">
            <span className="text-blue-600 font-bold block">IEC_FREQUENCY</span>
            <span className="text-slate-500 text-[11px]">Electrical Supply Cycle (50/60 Hz)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
