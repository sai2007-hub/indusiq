import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Sparkles,
  Globe,
  BookOpen,
  FileText,
  Zap,
  ArrowRight,
  Database,
  Layers,
  Upload,
  CheckCircle2,
} from 'lucide-react';

export const AnalyzeProductPage: React.FC = () => {
  const { launchDemoFlow, analyzeNewProduct, setCurrentPage } = useApp();

  const [productName, setProductName] = useState('X500 Industrial Motor');
  const [category, setCategory] = useState('3-Phase Induction Motor');
  const [manufacturer, setManufacturer] = useState('Example Motors');

  const [websiteText, setWebsiteText] = useState(
    'Heavy Duty X500 Industrial 3-Phase Induction Motor. Rated continuous output: 5 HP (3.7 kW). Voltage: 415V, 50Hz, 1440 RPM. Enclosure: IP55.'
  );
  const [catalogText, setCatalogText] = useState(
    'Model IND-X500-3P: 5 HP nominal output power, IP55 cast iron enclosure, 3 Phase, 415 Volts AC, 1440 RPM synchronous speed.'
  );
  const [datasheetText, setDatasheetText] = useState(
    'SECTION 3.2 ELECTRICAL SPECIFICATIONS: X500 Rev 2.4 features upgraded heavy-duty class H copper stator winding rated at 7.5 HP (5.5 kW) @ 415V 50Hz 3-Phase. Full load speed: 1440 RPM. Enclosure protection: IP55.'
  );

  const loadPreset = (presetName: string) => {
    if (presetName === 'x500') {
      setProductName('X500 Industrial Motor');
      setCategory('3-Phase Induction Motor');
      setManufacturer('Example Motors');
      setWebsiteText(
        'Heavy Duty X500 Industrial 3-Phase Induction Motor. Rated continuous output: 5 HP (3.7 kW). Voltage: 415V, 50Hz, 1440 RPM. Enclosure: IP55.'
      );
      setCatalogText(
        'Model IND-X500-3P: 5 HP nominal output power, IP55 cast iron enclosure, 3 Phase, 415 Volts AC, 1440 RPM synchronous speed.'
      );
      setDatasheetText(
        'SECTION 3.2 ELECTRICAL SPECIFICATIONS: X500 Rev 2.4 features upgraded heavy-duty class H copper stator winding rated at 7.5 HP (5.5 kW) @ 415V 50Hz 3-Phase. Full load speed: 1440 RPM. Enclosure protection: IP55.'
      );
    } else if (presetName === 'pump') {
      setProductName('HYDRA-GEAR 200');
      setCategory('Hydraulic Gear Pump');
      setManufacturer('Parker Precision');
      setWebsiteText('Parker HGP-200 Gear Pump. Max 250 Bar, 22.5 cc/rev displacement.');
      setCatalogText('Hydraulic Pump Series 200: Displacement 22.5 cc/rev, max continuous speed 3000 RPM.');
      setDatasheetText('Parker Engineering Datasheet HGP-200: 250 Bar nominal pressure, 3000 RPM peak, SAE 2-bolt flange.');
    } else if (presetName === 'sensor') {
      setProductName('SENSOPRESS-40');
      setCategory('Digital Pressure Transmitter');
      setManufacturer('Endress Sensors');
      setWebsiteText('Sensopress SP40 4-20mA pressure sensor, 0-10 Bar range.');
      setCatalogText('SP40 Transmitter: 2-wire 4-20mA output, 12-30V DC excitation.');
      setDatasheetText('SP40 Technical Spec: 0 to 10 Bar, ATEX Zone 1 certified, 4-20mA current loop.');
    }
  };

  const handleRunAnalysis = () => {
    // If it is the default X500 preset, trigger the official demo flow with exact 92% -> 96% state!
    if (productName.includes('X500')) {
      launchDemoFlow();
    } else {
      analyzeNewProduct(
        productName,
        category,
        manufacturer,
        websiteText,
        catalogText,
        datasheetText
      );
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Analyze Industrial Product Sources
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Ingest heterogeneous data from Websites, Catalogs, and Technical Engineering Datasheets.
          </p>
        </div>

        {/* Quick Demo Launch button */}
        <button
          onClick={launchDemoFlow}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-sm shadow-blue-500/30 transition-all cursor-pointer self-start"
        >
          <Zap className="w-4 h-4 fill-white" />
          <span>Quick Run X500 Demo Flow</span>
        </button>
      </div>

      {/* Preset Selector */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-blue-600 shrink-0" />
          <span className="text-xs font-bold text-slate-800">Quick Test Datasets:</span>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => loadPreset('x500')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              productName.includes('X500')
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            ⭐ X500 Motor (Power Conflict Demo)
          </button>
          <button
            onClick={() => loadPreset('pump')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              productName.includes('HYDRA')
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            Hydraulic Pump HGP-200
          </button>
          <button
            onClick={() => loadPreset('sensor')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              productName.includes('SENSOPRESS')
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            Pressure Transmitter SP-40
          </button>
        </div>
      </div>

      {/* Product Metadata Info */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
        <h2 className="text-sm font-bold uppercase tracking-wider text-slate-500">Asset Identity</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Product Name</label>
            <input
              type="text"
              value={productName}
              onChange={(e) => setProductName(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-800 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
            <input
              type="text"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-medium text-slate-800 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Manufacturer</label>
            <input
              type="text"
              value={manufacturer}
              onChange={(e) => setManufacturer(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-medium text-slate-800 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      {/* 3 Source Ingestion Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Source 1: Website */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-sky-600" />
              <span className="text-xs font-bold text-slate-900">Source 1: Official Website</span>
            </div>
            <span className="text-[11px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
              Weight: 85%
            </span>
          </div>

          <p className="text-[11px] text-slate-500 mt-2">
            Marketing description and catalog landing page text.
          </p>

          <textarea
            rows={6}
            value={websiteText}
            onChange={(e) => setWebsiteText(e.target.value)}
            className="mt-3 flex-1 w-full p-3 rounded-xl border border-slate-200 text-xs font-mono text-slate-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 bg-slate-50/50"
            placeholder="Paste website HTML / text..."
          />
        </div>

        {/* Source 2: Catalog */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-indigo-600" />
              <span className="text-xs font-bold text-slate-900">Source 2: Distributor Catalog</span>
            </div>
            <span className="text-[11px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
              Weight: 90%
            </span>
          </div>

          <p className="text-[11px] text-slate-500 mt-2">
            Published print catalog and distribution partner matrix.
          </p>

          <textarea
            rows={6}
            value={catalogText}
            onChange={(e) => setCatalogText(e.target.value)}
            className="mt-3 flex-1 w-full p-3 rounded-xl border border-slate-200 text-xs font-mono text-slate-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 bg-slate-50/50"
            placeholder="Paste distributor catalog OCR text..."
          />
        </div>

        {/* Source 3: Datasheet */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-emerald-600" />
              <span className="text-xs font-bold text-slate-900">Source 3: Engineering Datasheet</span>
            </div>
            <span className="text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100 font-bold">
              Weight: 98%
            </span>
          </div>

          <p className="text-[11px] text-slate-500 mt-2">
            Certified technical specifications and engineering test bench reports.
          </p>

          <textarea
            rows={6}
            value={datasheetText}
            onChange={(e) => setDatasheetText(e.target.value)}
            className="mt-3 flex-1 w-full p-3 rounded-xl border border-slate-200 text-xs font-mono text-slate-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 bg-slate-50/50"
            placeholder="Paste certified engineering datasheet..."
          />
        </div>
      </div>

      {/* Execution Action Button */}
      <div className="p-6 rounded-2xl bg-slate-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl">
        <div>
          <h3 className="text-base font-bold">Run AI Extraction & Multi-Source Cross-Check</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Parses parameters, normalizes engineering units, calculates Trust Score, and flags multi-source conflicts.
          </p>
        </div>

        <button
          onClick={handleRunAnalysis}
          id="run-ai-extraction-btn"
          className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md shadow-blue-500/30 transition-all cursor-pointer shrink-0"
        >
          <Sparkles className="w-4 h-4" />
          <span>Synthesize Product Intelligence</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
