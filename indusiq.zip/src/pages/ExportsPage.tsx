import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ProductAttribute } from '../types';
import {
  Download,
  Copy,
  Check,
  FileCode,
  FileSpreadsheet,
  Layers,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

export const ExportsPage: React.FC = () => {
  const { products, activeProduct, addToast } = useApp();
  const [exportFormat, setExportFormat] = useState<'json' | 'csv' | 'xml' | 'etim'>('json');
  const [onlyReady, setOnlyReady] = useState(false);
  const [copied, setCopied] = useState(false);

  const targetProducts = onlyReady
    ? products.filter((p) => p.status === 'READY_FOR_CATALOG')
    : products;

  // Generate JSON format
  const generateJSON = () => {
    const data = targetProducts.map((p) => ({
      id: p.id,
      product_name: p.name,
      model_number: p.modelNumber,
      sku: p.sku,
      category: p.category,
      manufacturer: p.manufacturer,
      catalog_status: p.status,
      trust_score: p.trustScore.overall,
      trust_metrics: {
        completeness_pct: p.trustScore.completeness,
        consistency_pct: p.trustScore.consistency,
        source_quality_pct: p.trustScore.sourceQuality,
        extraction_confidence_pct: p.trustScore.extractionConfidence,
      },
      verified_specifications: (Object.entries(p.attributes) as [string, ProductAttribute][]).reduce(
        (acc, [key, attr]) => {
          acc[key] = {
            name: attr.name,
            value: attr.value,
            unit: attr.unit,
            confidence: attr.confidence,
            is_conflicted: attr.isConflicted,
            is_missing: attr.isMissing,
            standard_key: attr.standardNormalizedKey,
            sources_count: attr.sources.length,
          };
          return acc;
        },
        {} as Record<string, any>
      ),
      provenance_sources: p.rawSources.map((s) => ({
        title: s.title,
        type: s.type,
        url_or_file: s.fileNameOrUrl,
        reliability_weight: s.reliabilityWeight,
      })),
      audit_ledger_records: p.auditHistory.length,
    }));

    return JSON.stringify(data, null, 2);
  };

  // Generate CSV format
  const generateCSV = () => {
    const headers = [
      'Model Number',
      'Product Name',
      'Category',
      'Manufacturer',
      'Status',
      'Trust Score (%)',
      'Rated Power',
      'Voltage',
      'Speed (RPM)',
      'Phase',
      'Frequency',
      'IP Rating',
      'Efficiency Class',
    ];

    const rows = targetProducts.map((p) => [
      `"${p.modelNumber}"`,
      `"${p.name}"`,
      `"${p.category}"`,
      `"${p.manufacturer}"`,
      `"${p.status}"`,
      p.trustScore.overall,
      `"${p.attributes['power']?.value || 'N/A'}"`,
      `"${p.attributes['voltage']?.value || 'N/A'}"`,
      `"${p.attributes['speed']?.value || 'N/A'}"`,
      `"${p.attributes['phase']?.value || 'N/A'}"`,
      `"${p.attributes['frequency']?.value || 'N/A'}"`,
      `"${p.attributes['ipRating']?.value || 'N/A'}"`,
      `"${p.attributes['efficiency']?.value || 'N/A'}"`,
    ]);

    return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  };

  // Generate XML format
  const generateXML = () => {
    const items = targetProducts
      .map(
        (p) => `  <Product id="${p.id}" model="${p.modelNumber}">
    <Name>${p.name}</Name>
    <Manufacturer>${p.manufacturer}</Manufacturer>
    <TrustScore value="${p.trustScore.overall}" status="${p.status}" />
    <Specifications>
${(Object.values(p.attributes) as ProductAttribute[])
  .map(
    (a) => `      <Spec key="${a.key}" name="${a.name}" value="${a.value || ''}" confidence="${a.confidence}" />`
  )
  .join('\n')}
    </Specifications>
  </Product>`
      )
      .join('\n');

    return `<?xml version="1.0" encoding="UTF-8"?>\n<IndustrialProductCatalog version="2.4">\n${items}\n</IndustrialProductCatalog>`;
  };

  const getExportContent = () => {
    switch (exportFormat) {
      case 'json':
        return generateJSON();
      case 'csv':
        return generateCSV();
      case 'xml':
      case 'etim':
        return generateXML();
      default:
        return generateJSON();
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getExportContent());
    setCopied(true);
    addToast('Copied to Clipboard', `Exported ${exportFormat.toUpperCase()} data copied to system clipboard.`, 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const content = getExportContent();
    const blob = new Blob([content], {
      type: exportFormat === 'json' ? 'application/json' : 'text/plain',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `indusiq_catalog_export_${Date.now()}.${exportFormat === 'json' ? 'json' : exportFormat === 'csv' ? 'csv' : 'xml'}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    addToast('File Downloaded', `Successfully exported catalog dataset in .${exportFormat} format.`, 'success');
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Data Syndication & Exports
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Export validated, conflict-free product intelligence for ERP, PIM, e-Commerce, and Distributor Catalogs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="px-4 py-2.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-xs font-bold text-slate-800 shadow-xs transition-colors cursor-pointer inline-flex items-center gap-1.5"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-500" />}
            <span>{copied ? 'Copied!' : 'Copy to Clipboard'}</span>
          </button>

          <button
            onClick={handleDownload}
            className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/25 transition-all cursor-pointer inline-flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" />
            <span>Download .{exportFormat.toUpperCase()}</span>
          </button>
        </div>
      </div>

      {/* Control Bar: Format Selector & Filters */}
      <div className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-slate-500 mr-2">Syndication Schema:</span>
          {[
            { id: 'json', label: 'Standard JSON', icon: FileCode },
            { id: 'csv', label: 'Clean Industrial CSV', icon: FileSpreadsheet },
            { id: 'xml', label: 'ERP / PIM XML', icon: Layers },
            { id: 'etim', label: 'ETIM / GS1 Format', icon: ShieldCheck },
          ].map((fmt) => {
            const Icon = fmt.icon;
            const isSelected = exportFormat === fmt.id;

            return (
              <button
                key={fmt.id}
                onClick={() => setExportFormat(fmt.id as any)}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-xs shadow-blue-500/20'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{fmt.label}</span>
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-2 border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-100">
          <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={onlyReady}
              onChange={(e) => setOnlyReady(e.target.checked)}
              className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
            />
            <span>Export only READY FOR CATALOG items ({products.filter((p) => p.status === 'READY_FOR_CATALOG').length})</span>
          </label>
        </div>
      </div>

      {/* Code / Output Preview Area */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 shadow-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-rose-500" />
            <span className="w-3 h-3 rounded-full bg-amber-500" />
            <span className="w-3 h-3 rounded-full bg-emerald-500" />
            <span className="ml-2 text-xs font-mono text-slate-400">
              indusiq_catalog_export.{exportFormat} ({targetProducts.length} items formatted)
            </span>
          </div>

          <span className="text-[11px] font-mono text-slate-500 uppercase">
            Validated by Trust Engine
          </span>
        </div>

        <div className="p-6 overflow-x-auto max-h-[500px] text-xs font-mono text-slate-300 leading-relaxed bg-slate-900 select-all">
          <pre>{getExportContent()}</pre>
        </div>
      </div>
    </div>
  );
};
