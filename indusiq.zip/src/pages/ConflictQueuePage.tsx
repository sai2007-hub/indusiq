import React from 'react';
import { useApp } from '../context/AppContext';
import {
  AlertTriangle,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  History,
  ExternalLink,
  Zap,
} from 'lucide-react';

export const ConflictQueuePage: React.FC = () => {
  const {
    products,
    openEvidenceDrawer,
    setActiveProductId,
    setCurrentPage,
    resolveConflict,
    launchDemoFlow,
  } = useApp();

  // Aggregate all conflicts across all products
  const allConflictsWithProduct = products.flatMap((prod) =>
    prod.conflicts.map((conf) => ({
      product: prod,
      conflict: conf,
    }))
  );

  const activeConflicts = allConflictsWithProduct.filter((item) => !item.conflict.isResolved);
  const resolvedConflicts = allConflictsWithProduct.filter((item) => item.conflict.isResolved);

  return (
    <div className="space-y-8 pb-16">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Human-in-the-Loop Review Queue
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Resolve multi-source contradictions with full provenance context and certified recommendations.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={launchDemoFlow}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-sm shadow-blue-500/30 transition-all cursor-pointer"
          >
            <Zap className="w-4 h-4 fill-white" />
            <span>Test X500 Power Conflict Demo</span>
          </button>
        </div>
      </div>

      {/* Active Unresolved Conflicts */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-slate-900">Active Conflict Backlog</h2>
            <span
              className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                activeConflicts.length > 0
                  ? 'bg-rose-100 text-rose-800 border border-rose-200'
                  : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
              }`}
            >
              {activeConflicts.length} Action Required
            </span>
          </div>
          {activeConflicts.length === 0 && (
            <span className="text-xs text-emerald-600 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-4 h-4" /> All conflicts across catalog are resolved!
            </span>
          )}
        </div>

        {activeConflicts.length === 0 ? (
          <div className="p-10 rounded-3xl bg-white border border-emerald-200 text-center space-y-3 shadow-xs">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Zero Pending Conflicts</h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              All multi-source discrepancies have been validated by engineering review. The catalog is ready for syndication.
            </p>
            <div className="pt-2">
              <button
                onClick={() => setCurrentPage('exports')}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all cursor-pointer inline-flex items-center gap-1.5"
              >
                <span>Proceed to Data Syndication & Exports</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {activeConflicts.map(({ product, conflict }) => (
              <div
                key={conflict.id}
                className="p-6 rounded-3xl bg-white border border-rose-200 shadow-xs space-y-5"
              >
                {/* Conflict Top Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-rose-700 uppercase tracking-wider flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-600" /> Multi-Source Value Contradiction
                      </span>
                      <span className="text-slate-300">•</span>
                      <span className="text-xs font-mono font-bold text-slate-700">
                        {product.name} ({product.modelNumber})
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-slate-900 mt-1">
                      Conflicting Attribute: <span className="text-blue-600">{conflict.attributeName}</span>
                    </h3>
                  </div>

                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-800 border border-rose-200 self-start sm:self-auto">
                    High Severity
                  </span>
                </div>

                {/* Conflicting Source Values Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {conflict.conflictingValues.map((val, idx) => (
                    <div
                      key={idx}
                      className={`p-4 rounded-2xl border transition-all ${
                        val.recommended
                          ? 'border-emerald-300 bg-emerald-50/40'
                          : 'border-slate-200 bg-slate-50/60'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-slate-600">{val.sourceName}</span>
                        {val.recommended && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            Recommended
                          </span>
                        )}
                      </div>

                      <div className="mt-2 flex items-baseline gap-2">
                        <span className="text-xl font-black font-mono text-slate-900">{val.value}</span>
                        <span className="text-[11px] font-mono text-slate-500">({val.sourceType})</span>
                      </div>

                      {val.reasoning && (
                        <p className="mt-2 text-xs text-slate-600 leading-relaxed italic">
                          {val.reasoning}
                        </p>
                      )}
                    </div>
                  ))}
                </div>

                {/* Resolution CTA Bar */}
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <p className="text-xs text-slate-600">
                    Resolving this conflict increases <strong className="text-slate-900">{product.name}</strong> Trust Score from <strong>92% → 96%</strong>.
                  </p>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => {
                        setActiveProductId(product.id);
                        openEvidenceDrawer(conflict.attributeKey);
                      }}
                      className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer inline-flex items-center gap-1.5"
                    >
                      <span>Open Evidence Inspector</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>

                    {/* Quick 1-Click Resolve to 7.5 HP button */}
                    <button
                      onClick={() => {
                        resolveConflict(
                          product.id,
                          conflict.attributeKey,
                          '7.5 HP',
                          'Datasheet Rev 2.4 certified engineering upgrade to Class H winding.'
                        );
                      }}
                      className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer inline-flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>1-Click Resolve to 7.5 HP</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Resolved History Archive */}
      {resolvedConflicts.length > 0 && (
        <div className="space-y-4 pt-6">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-slate-500" />
            <h2 className="text-base font-bold text-slate-900">Resolution History & Audit Log</h2>
          </div>

          <div className="divide-y divide-slate-200 bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
            {resolvedConflicts.map(({ product, conflict }) => (
              <div key={conflict.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{product.name}</span>
                    <span className="text-slate-300">•</span>
                    <span className="text-xs font-mono text-slate-500">{conflict.attributeName}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                      RESOLVED
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    Confirmed Value: <strong className="text-emerald-700 font-mono">{conflict.resolvedValue}</strong>
                    {conflict.resolutionReason && ` — "${conflict.resolutionReason}"`}
                  </p>
                </div>

                <div className="text-right text-[11px] text-slate-400 font-mono shrink-0">
                  <div>Auditor: {conflict.resolvedBy || 'Lead Technical Reviewer'}</div>
                  <div>{conflict.resolvedAt?.slice(0, 10) || 'Today'}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
