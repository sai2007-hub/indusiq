import React from 'react';
import { useApp } from '../context/AppContext';
import {
  ShieldCheck,
  Zap,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  Cpu,
  Layers,
  Database,
  Search,
  Sparkles,
  Award,
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const { launchDemoFlow, setCurrentPage } = useApp();

  return (
    <div className="space-y-12 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-white rounded-3xl border border-slate-200 p-8 sm:p-12 shadow-sm">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-800 border border-blue-200 mb-6">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>Industrial Product Intelligence & Trust Verification</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
            Turn scattered industrial data into <span className="text-blue-600">trusted product intelligence.</span>
          </h1>

          <p className="mt-5 text-lg sm:text-xl font-medium text-slate-700 leading-relaxed">
            “Don't just extract product data. Prove whether the data can be trusted.”
          </p>

          <p className="mt-3 text-sm text-slate-500 max-w-2xl leading-relaxed">
            Industrial manufacturers and distributors lose millions in returns and downtime from conflicting specs across PDFs, websites, and legacy catalogs. INDUSIQ ingests multi-source data, flags contradictions, calculates an explainable Trust Score, and produces audit-backed catalog readiness.
          </p>

          {/* Action CTAs */}
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <button
              onClick={launchDemoFlow}
              id="hero-launch-demo-btn"
              className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-98 text-white font-bold text-sm shadow-lg shadow-blue-500/25 transition-all cursor-pointer"
            >
              <Zap className="w-4 h-4 fill-white" />
              <span>Launch 1-Click Interactive Demo (X500 Motor)</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => setCurrentPage('dashboard')}
              className="px-5 py-3.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-sm transition-colors cursor-pointer border border-slate-200"
            >
              View Executive Dashboard
            </button>
          </div>
        </div>

        {/* Hero Interactive Visual Snapshot */}
        <div className="mt-10 p-6 rounded-2xl bg-slate-900 text-white border border-slate-800 shadow-xl">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800 text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
              <span className="font-mono font-bold text-slate-200">LIVE DEMO PREVIEW: X500 Industrial Motor</span>
            </div>
            <span className="font-mono text-slate-400">IEC 3-Phase Induction Motor | Example Motors</span>
          </div>

          <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Raw Ingestion */}
            <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/60">
              <div className="flex items-center justify-between text-xs text-slate-400 font-semibold mb-2">
                <span>1. Multi-Source Ingest</span>
                <Database className="w-4 h-4 text-blue-400" />
              </div>
              <ul className="text-xs space-y-1.5 text-slate-300 font-mono">
                <li>• Webpage: <span className="text-amber-400 font-bold">5 HP</span></li>
                <li>• Master Catalog: <span className="text-amber-400 font-bold">5 HP</span></li>
                <li>• Datasheet Rev 2.4: <span className="text-emerald-400 font-bold">7.5 HP</span></li>
              </ul>
            </div>

            {/* AI Discrepancy Engine */}
            <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/60">
              <div className="flex items-center justify-between text-xs text-slate-400 font-semibold mb-2">
                <span>2. AI Cross-Reference</span>
                <AlertTriangle className="w-4 h-4 text-rose-400" />
              </div>
              <div className="text-xs text-slate-300">
                <span className="inline-block px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 font-mono font-bold text-[11px] mb-1">
                  ⚠ POWER CONFLICT (5 vs 7.5 HP)
                </span>
                <p className="text-[11px] text-slate-400 leading-snug">
                  Datasheet has 98% reliability score vs 85% web marketing text.
                </p>
              </div>
            </div>

            {/* Trust Engine Output */}
            <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/60">
              <div className="flex items-center justify-between text-xs text-slate-400 font-semibold mb-2">
                <span>3. Explainable Trust Score</span>
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-mono font-black text-emerald-400">92% → 96%</div>
                  <div className="text-[10px] text-slate-400">Post-Verification Score</div>
                </div>
                <button
                  onClick={launchDemoFlow}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold cursor-pointer"
                >
                  Run Demo
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* The 4-Pillar Trust Framework */}
      <section className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">The 4-Pillar Trust Engine</h2>
          <p className="text-sm text-slate-500 mt-1">
            Unlike generic LLM wrappers that hallucinate specs, INDUSIQ calculates a deterministic, explainable Trust Score.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold mb-4">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Completeness (25%)</h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Measures percentage of critical schema attributes populated (Voltage, Speed, Phase, Efficiency). Flags missing attributes.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold mb-4">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Consistency (40%)</h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Detects contradictions across independent documents. Flags exact value differences and units between catalogs and datasheets.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold mb-4">
              <Award className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Source Quality (20%)</h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Weights certified engineering datasheets (98%) higher than distributor catalogs (90%) and marketing webpages (85%).
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold mb-4">
              <Cpu className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Extraction Conf. (15%)</h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Measures optical character and parsing certainty for technical values, decimal points, and physical units.
            </p>
          </div>
        </div>
      </section>

      {/* Before vs After Comparison */}
      <section className="p-8 rounded-3xl bg-slate-50 border border-slate-200">
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight">The Industrial Catalog Reality</h2>
        <p className="text-sm text-slate-500 mt-1">Comparing traditional messy catalog preparation vs INDUSIQ automated verification.</p>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Before */}
          <div className="p-6 rounded-2xl bg-white border border-rose-200 shadow-xs">
            <div className="flex items-center gap-2 text-rose-700 font-bold text-sm mb-3">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
              <span>BEFORE: Unvalidated Scrapes & PDFs</span>
            </div>
            <ul className="space-y-3 text-xs text-slate-600">
              <li className="flex items-start gap-2">
                <span className="text-rose-500 font-bold">✕</span>
                <span>Conflicting specs go unnoticed (e.g. selling 5 HP motor that actually requires 7.5 HP electrical feed).</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-500 font-bold">✕</span>
                <span>Missing required fields like Energy Efficiency class lead to non-compliance fines.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-500 font-bold">✕</span>
                <span>Zero provenance: Nobody knows which engineer or PDF claimed the spec.</span>
              </li>
            </ul>
          </div>

          {/* After */}
          <div className="p-6 rounded-2xl bg-white border border-emerald-200 shadow-xs">
            <div className="flex items-center gap-2 text-emerald-700 font-bold text-sm mb-3">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span>AFTER: INDUSIQ Provenance Intelligence</span>
            </div>
            <ul className="space-y-3 text-xs text-slate-600">
              <li className="flex items-start gap-2">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Automatic multi-source reconciliation highlights conflicting claims with 1-click human verification.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Standard rule engine suggests baseline imputations (e.g. IEC 60034-30 IE3 efficiency).</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Immutable audit trail & instant JSON/CSV export ready for ERP, PIM, and eCommerce syndication.</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Bottom Launch Banner */}
      <section className="p-8 rounded-3xl bg-blue-600 text-white flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl shadow-blue-500/10">
        <div>
          <h3 className="text-2xl font-extrabold tracking-tight">Ready to test the X500 Demo Flow?</h3>
          <p className="text-sm text-blue-100 mt-1 max-w-xl">
            Experience real-time AI ingestion, power conflict resolution from 5 HP to 7.5 HP, trust score leap to 96%, and clean data export.
          </p>
        </div>
        <button
          onClick={launchDemoFlow}
          className="shrink-0 inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-white hover:bg-slate-100 text-blue-600 font-bold text-sm shadow-md transition-all cursor-pointer"
        >
          <Zap className="w-4 h-4 fill-blue-600" />
          <span>Launch Demo Now</span>
        </button>
      </section>
    </div>
  );
};
