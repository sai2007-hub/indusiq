import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ProductAttribute } from '../types';
import {
  FileCheck2,
  Globe,
  BookOpen,
  FileText,
  Search,
  ExternalLink,
  ShieldCheck,
  AlertTriangle,
  ArrowRight,
  Filter,
} from 'lucide-react';

export const EvidenceCenterPage: React.FC = () => {
  const { activeProduct, openEvidenceDrawer, products, setActiveProductId } = useApp();
  const [filterType, setFilterType] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');

  if (!activeProduct) return null;

  const sources = activeProduct.rawSources.filter((s) => {
    if (filterType !== 'all' && s.type !== filterType) return false;
    if (searchTerm && !s.title.toLowerCase().includes(searchTerm.toLowerCase()) && !s.contentSnippet.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    return true;
  });

  return (
    <div className="space-y-8 pb-16">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Evidence & Provenance Center
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Audit-grade document repository linking every technical attribute to its original source citation.
          </p>
        </div>

        {/* Product selector */}
        <div className="flex items-center gap-2 bg-white border border-slate-200 p-2 rounded-xl shadow-xs">
          <span className="text-xs font-semibold text-slate-500">Asset:</span>
          <select
            value={activeProduct.id}
            onChange={(e) => setActiveProductId(e.target.value)}
            className="text-xs font-bold text-slate-800 bg-transparent focus:outline-none cursor-pointer"
          >
            {products.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} ({p.modelNumber})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search raw snippets, model references, or specs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-slate-50/50"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-xs font-medium text-slate-500">Source Type:</span>
          {['all', 'website', 'catalog', 'datasheet'].map((t) => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-colors cursor-pointer ${
                filterType === t
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Document Provenance Cards */}
      <div className="space-y-5">
        {sources.map((src) => {
          const isDatasheet = src.type === 'datasheet';
          const isCatalog = src.type === 'catalog';

          return (
            <div
              key={src.id}
              className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4 hover:border-slate-300 transition-colors"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center">
                    {isDatasheet ? (
                      <FileText className="w-5 h-5 text-emerald-600" />
                    ) : isCatalog ? (
                      <BookOpen className="w-5 h-5 text-indigo-600" />
                    ) : (
                      <Globe className="w-5 h-5 text-sky-600" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">{src.title}</h3>
                    <p className="text-xs text-slate-500 font-mono">
                      File / URL: {src.fileNameOrUrl} • Ingested: {src.uploadDate}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold font-mono bg-emerald-50 text-emerald-800 border border-emerald-200">
                    Provenance Weight: {Math.round(src.reliabilityWeight * 100)}%
                  </span>
                  <span className="text-xs font-medium text-slate-500">
                    {src.attributeCountExtracted} attributes anchored
                  </span>
                </div>
              </div>

              {/* Exact Snippet Box */}
              <div>
                <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5">
                  <span className="font-semibold">Original Document Excerpt:</span>
                  <span className="font-mono text-[11px]">OCR / Text Layer v2.1</span>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono text-slate-800 leading-relaxed">
                  "{src.contentSnippet}"
                </div>
              </div>

              {/* Related Extracted Attributes in this doc */}
              <div className="pt-2 flex flex-wrap items-center gap-2">
                <span className="text-xs font-semibold text-slate-400">Anchored Specs:</span>
                {(Object.values(activeProduct.attributes) as ProductAttribute[])
                  .filter((a) => a.sources.some((s) => s.sourceId === src.id))
                  .map((attr) => (
                    <button
                      key={attr.key}
                      onClick={() => openEvidenceDrawer(attr.key)}
                      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition-colors cursor-pointer ${
                        attr.isConflicted
                          ? 'bg-rose-100 text-rose-800 border border-rose-200'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                      }`}
                    >
                      <span>{attr.name}: {attr.value || 'N/A'}</span>
                      {attr.isConflicted && <AlertTriangle className="w-3 h-3 text-rose-600" />}
                    </button>
                  ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
