import React from 'react';
import { useApp } from '../context/AppContext';
import {
  ShieldCheck,
  Sliders,
  Award,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Layers,
  FileCheck,
} from 'lucide-react';
import { DEFAULT_TRUST_WEIGHTS } from '../utils/trustScore';

export const TrustCenterPage: React.FC = () => {
  const { trustWeights, setTrustWeights, activeProduct, addToast } = useApp();

  const handleWeightChange = (key: keyof typeof trustWeights, val: number) => {
    setTrustWeights({
      ...trustWeights,
      [key]: val,
    });
  };

  const handleResetWeights = () => {
    setTrustWeights(DEFAULT_TRUST_WEIGHTS);
    addToast('Weights Reset', 'Restored default Trust Score weighting policy.', 'info');
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Trust Engine & Governance Center
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Deterministic, explainable mathematical scoring engine with customizable enterprise weighting policies.
          </p>
        </div>

        <button
          onClick={handleResetWeights}
          className="px-4 py-2 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-xs font-bold text-slate-700 shadow-xs transition-colors cursor-pointer inline-flex items-center gap-1.5 self-start"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset to Default Policy</span>
        </button>
      </div>

      {/* Mathematical Formula Box */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 text-white shadow-xl border border-slate-800 space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-bold">Standard Explainable Prototype Formula</h2>
              <p className="text-xs text-slate-400 font-mono">
                Deterministic Composite Trust Index (Zero Black-Box LLM Hallucination)
              </p>
            </div>
          </div>
          <span className="text-xs font-mono bg-blue-500/20 text-blue-300 px-3 py-1 rounded-full border border-blue-500/30">
            Current Score: {activeProduct?.trustScore.overall}%
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 font-mono text-xs sm:text-sm text-slate-200 leading-relaxed overflow-x-auto">
          <div className="text-blue-400 font-bold mb-1">Mathematical Formulation:</div>
          TrustScore = (W_completeness × Completeness) + (W_consistency × Consistency) + (W_sourceQuality × SourceQuality) + (W_confidence × ExtractionConfidence)
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs font-mono">
          <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/50">
            <span className="text-slate-400 block text-[10px]">W_completeness:</span>
            <span className="text-base font-bold text-white">{(trustWeights.completenessWeight * 100).toFixed(0)}%</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/50">
            <span className="text-slate-400 block text-[10px]">W_consistency:</span>
            <span className="text-base font-bold text-amber-400">{(trustWeights.consistencyWeight * 100).toFixed(0)}%</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/50">
            <span className="text-slate-400 block text-[10px]">W_sourceQuality:</span>
            <span className="text-base font-bold text-indigo-400">{(trustWeights.sourceQualityWeight * 100).toFixed(0)}%</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/50">
            <span className="text-slate-400 block text-[10px]">W_confidence:</span>
            <span className="text-base font-bold text-emerald-400">{(trustWeights.confidenceWeight * 100).toFixed(0)}%</span>
          </div>
        </div>
      </div>

      {/* Interactive Weights Policy Sliders */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-6">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-bold text-slate-900">Custom Policy Weighting Sliders</h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Adjust weighting factors to align with your organization's compliance tolerance.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Completeness Slider */}
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800">Completeness Factor (Missing Fields)</span>
              <span className="text-xs font-mono font-bold text-blue-600">
                {(trustWeights.completenessWeight * 100).toFixed(0)}%
              </span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.60"
              step="0.05"
              value={trustWeights.completenessWeight}
              onChange={(e) => handleWeightChange('completenessWeight', parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
            <p className="text-[11px] text-slate-500">
              Penalizes unstated specifications in catalog entries (e.g. Missing efficiency rating).
            </p>
          </div>

          {/* Consistency Slider */}
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800">Consistency Factor (Multi-Source Contradictions)</span>
              <span className="text-xs font-mono font-bold text-amber-600">
                {(trustWeights.consistencyWeight * 100).toFixed(0)}%
              </span>
            </div>
            <input
              type="range"
              min="0.10"
              max="0.60"
              step="0.05"
              value={trustWeights.consistencyWeight}
              onChange={(e) => handleWeightChange('consistencyWeight', parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-amber-600"
            />
            <p className="text-[11px] text-slate-500">
              Heavily penalizes conflicting claims (e.g. Website 5 HP vs Datasheet 7.5 HP).
            </p>
          </div>

          {/* Source Quality Slider */}
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800">Source Quality Factor (Provenance Rank)</span>
              <span className="text-xs font-mono font-bold text-indigo-600">
                {(trustWeights.sourceQualityWeight * 100).toFixed(0)}%
              </span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.50"
              step="0.05"
              value={trustWeights.sourceQualityWeight}
              onChange={(e) => handleWeightChange('sourceQualityWeight', parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
            <p className="text-[11px] text-slate-500">
              Weights certified engineering datasheets higher than marketing blurbs.
            </p>
          </div>

          {/* Extraction Confidence Slider */}
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800">Extraction Confidence Factor (OCR/NER)</span>
              <span className="text-xs font-mono font-bold text-emerald-600">
                {(trustWeights.confidenceWeight * 100).toFixed(0)}%
              </span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.40"
              step="0.05"
              value={trustWeights.confidenceWeight}
              onChange={(e) => handleWeightChange('confidenceWeight', parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
            />
            <p className="text-[11px] text-slate-500">
              Evaluates AI confidence in token boundaries, decimal precision, and engineering units.
            </p>
          </div>
        </div>
      </div>

      {/* Industrial Compliance Standards Verification Checklist */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4">
        <h2 className="text-lg font-bold text-slate-900">Supported Industrial Standards & Compliance</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-1">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>IEC 60034-1 & 60034-30</span>
            </div>
            <p className="text-xs text-slate-500">
              Rotating electrical machines standard ratings, temperature rise, and IE1–IE4 energy efficiency classes.
            </p>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-1">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>IEC 60529 (IP Ingress Protection)</span>
            </div>
            <p className="text-xs text-slate-500">
              Validation for solid particulate (IP5X, IP6X) and moisture ingress protection enclosures.
            </p>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-1">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>ETIM & GS1 Standard Schema</span>
            </div>
            <p className="text-xs text-slate-500">
              Cross-industry technical classification structure ready for direct PIM / ERP syndication.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
