import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Package,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  Zap,
  ArrowRight,
  TrendingUp,
  Activity,
  FileCheck2,
  Cpu,
  Layers,
  Sparkles,
} from 'lucide-react';

export const DashboardPage: React.FC = () => {
  const {
    products,
    totalProductsCount,
    readyForCatalogCount,
    totalConflictsCount,
    averageTrustScore,
    launchDemoFlow,
    setCurrentPage,
    setActiveProductId,
    openEvidenceDrawer,
  } = useApp();

  const x500 = products.find((p) => p.id === 'prod-x500') || products[0];
  const hasX500Conflict = x500?.conflicts.some((c) => !c.isResolved);

  return (
    <div className="space-y-8 pb-16">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Executive Intelligence Dashboard
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Real-time catalog ingestion health, conflict queues, and trust score telemetry.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={launchDemoFlow}
            id="dash-launch-demo-btn"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-sm shadow-blue-500/30 transition-all cursor-pointer"
          >
            <Zap className="w-4 h-4 fill-white" />
            <span>Launch X500 Demo Flow</span>
          </button>

          <button
            onClick={() => setCurrentPage('analyze')}
            className="px-4 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-slate-800 text-xs font-bold border border-slate-200 shadow-xs transition-colors cursor-pointer"
          >
            + Analyze New Asset
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Total Assets */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Total Catalog Assets</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900 font-mono">{totalProductsCount}</span>
            <span className="text-xs font-semibold text-emerald-600">+100% Ingested</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">3 multi-source documents indexed</p>
        </div>

        {/* Ready for Catalog */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Catalog Ready (Verified)</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-emerald-600 font-mono">{readyForCatalogCount}</span>
            <span className="text-xs font-semibold text-slate-500">of {totalProductsCount} items</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            {readyForCatalogCount === totalProductsCount
              ? '100% Catalog Ready'
              : `${totalProductsCount - readyForCatalogCount} require verification`}
          </p>
        </div>

        {/* Active Conflict Queue */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Conflict Queue</span>
            <div
              className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                totalConflictsCount > 0 ? 'bg-rose-50 text-rose-600 animate-pulse' : 'bg-slate-100 text-slate-400'
              }`}
            >
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span
              className={`text-3xl font-black font-mono ${
                totalConflictsCount > 0 ? 'text-rose-600' : 'text-slate-900'
              }`}
            >
              {totalConflictsCount}
            </span>
            {totalConflictsCount > 0 ? (
              <span className="text-xs font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded">Action Needed</span>
            ) : (
              <span className="text-xs font-semibold text-emerald-600">Zero Conflicts</span>
            )}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Multi-source contradictions</p>
        </div>

        {/* Avg Trust Score */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Mean Trust Index</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-blue-600 font-mono">{averageTrustScore}%</span>
            <span className="text-xs font-semibold text-emerald-600">Grade: AAA</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Explainable weighted score</p>
        </div>
      </div>

      {/* High Priority Conflict Alert (Interactive X500 Shortcut) */}
      {hasX500Conflict && (
        <div className="p-6 rounded-2xl bg-amber-50/90 border border-amber-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0 mt-0.5">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-amber-950">High-Priority Conflict: X500 Industrial Motor</h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                  Power Mismatch (5 HP vs 7.5 HP)
                </span>
              </div>
              <p className="text-xs text-amber-900/80 mt-1 max-w-2xl leading-relaxed">
                The AI Cross-Reference engine detected conflicting rated power claims between official website (5 HP) and engineering datasheet (7.5 HP). Resolving this conflict will boost Trust Score from <strong>92% → 96%</strong> and mark the asset ready for catalog syndication.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => {
                setActiveProductId('prod-x500');
                setCurrentPage('intelligence');
                openEvidenceDrawer('power');
              }}
              className="px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-xs transition-all cursor-pointer inline-flex items-center gap-1.5"
            >
              <span>Inspect Evidence & Resolve</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Main Grid: Catalog Assets List & Trust Framework Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Ingested Asset Inventory */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">Ingested Industrial Assets</h2>
              <p className="text-xs text-slate-500 mt-0.5">Multi-source intelligence & validation state</p>
            </div>
            <button
              onClick={() => setCurrentPage('products')}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
            >
              <span>View Full Catalog</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {products.map((product) => {
              const activeConflicts = product.conflicts.filter((c) => !c.isResolved);
              const hasConflict = activeConflicts.length > 0;

              return (
                <div
                  key={product.id}
                  onClick={() => {
                    setActiveProductId(product.id);
                    setCurrentPage('intelligence');
                  }}
                  className="p-5 hover:bg-slate-50/80 transition-colors cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="flex items-start gap-3.5">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0 font-mono font-bold text-xs">
                      {product.modelNumber.slice(0, 4)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-slate-900 hover:text-blue-600 transition-colors">
                          {product.name}
                        </h4>
                        {hasConflict ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                            ⚠ {activeConflicts.length} Conflict
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            READY FOR CATALOG
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {product.category} • <span className="text-slate-700 font-medium">{product.manufacturer}</span>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-6 sm:justify-end">
                    <div>
                      <div className="text-xs text-slate-400 text-right">Trust Score</div>
                      <div className="text-base font-black font-mono text-slate-800 text-right">
                        {product.trustScore.overall}%
                      </div>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveProductId(product.id);
                        setCurrentPage('intelligence');
                      }}
                      className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                    >
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 1 Col: Trust Score Breakdown & Formula */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 space-y-5">
          <div>
            <h2 className="text-base font-bold text-slate-900">Explainable Trust Telemetry</h2>
            <p className="text-xs text-slate-500 mt-0.5">Four-factor composite score calculation</p>
          </div>

          <div className="space-y-3.5">
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-semibold text-slate-700">Completeness (25%)</span>
                <span className="font-mono font-bold text-slate-900">{x500.trustScore.completeness}%</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div className="bg-blue-600 h-full" style={{ width: `${x500.trustScore.completeness}%` }} />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-semibold text-slate-700">Consistency (40%)</span>
                <span className="font-mono font-bold text-slate-900">{x500.trustScore.consistency}%</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div
                  className={`h-full ${x500.trustScore.consistency < 90 ? 'bg-amber-500' : 'bg-emerald-600'}`}
                  style={{ width: `${x500.trustScore.consistency}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-semibold text-slate-700">Source Quality (20%)</span>
                <span className="font-mono font-bold text-slate-900">{x500.trustScore.sourceQuality}%</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div className="bg-indigo-600 h-full" style={{ width: `${x500.trustScore.sourceQuality}%` }} />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-semibold text-slate-700">Extraction Confidence (15%)</span>
                <span className="font-mono font-bold text-slate-900">{x500.trustScore.extractionConfidence}%</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div className="bg-emerald-600 h-full" style={{ width: `${x500.trustScore.extractionConfidence}%` }} />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 text-xs text-slate-500">
            <p className="font-mono text-[11px] leading-relaxed bg-slate-50 p-2.5 rounded-lg border border-slate-100">
              Formula: (0.25×Comp) + (0.40×Cons) + (0.20×Src) + (0.15×Conf)
            </p>
          </div>

          <button
            onClick={() => setCurrentPage('trust')}
            className="w-full py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-colors cursor-pointer text-center block"
          >
            Open Trust Center & Adjust Weights
          </button>
        </div>
      </div>
    </div>
  );
};
