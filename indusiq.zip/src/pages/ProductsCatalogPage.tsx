import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Package,
  Search,
  Filter,
  ArrowRight,
  AlertTriangle,
  CheckCircle2,
  ShieldCheck,
  Download,
  Plus,
} from 'lucide-react';

export const ProductsCatalogPage: React.FC = () => {
  const { products, setActiveProductId, setCurrentPage, openEvidenceDrawer } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'ready' | 'conflict' | 'review'>('all');

  const filteredProducts = products.filter((p) => {
    if (statusFilter === 'ready' && p.status !== 'READY_FOR_CATALOG') return false;
    if (statusFilter === 'conflict' && p.status !== 'CONFLICT_DETECTED') return false;
    if (statusFilter === 'review' && p.status !== 'NEEDS_REVIEW') return false;

    if (
      searchTerm &&
      !p.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
      !p.modelNumber.toLowerCase().includes(searchTerm.toLowerCase()) &&
      !p.manufacturer.toLowerCase().includes(searchTerm.toLowerCase()) &&
      !p.category.toLowerCase().includes(searchTerm.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  return (
    <div className="space-y-8 pb-16">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Industrial Products Catalog
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Master database of validated, cross-referenced industrial products and assemblies.
          </p>
        </div>

        <button
          onClick={() => setCurrentPage('analyze')}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer self-start"
        >
          <Plus className="w-4 h-4" />
          <span>Ingest New Product</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search by product name, model number, SKU, or manufacturer..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-slate-50/50"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-xs font-medium text-slate-500">Status:</span>
          {[
            { id: 'all', label: 'All Assets' },
            { id: 'ready', label: 'Ready for Catalog' },
            { id: 'conflict', label: 'Conflicts' },
            { id: 'review', label: 'Needs Review' },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setStatusFilter(f.id as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                statusFilter === f.id
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Catalog Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-mono font-bold text-slate-500 uppercase tracking-wider">
                <th className="py-3.5 px-6">Asset & Model</th>
                <th className="py-3.5 px-6">Category</th>
                <th className="py-3.5 px-6">Manufacturer</th>
                <th className="py-3.5 px-6">Catalog Status</th>
                <th className="py-3.5 px-6">Trust Score</th>
                <th className="py-3.5 px-6 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredProducts.map((prod) => {
                const isReady = prod.status === 'READY_FOR_CATALOG';
                const isConflicted = prod.status === 'CONFLICT_DETECTED';

                return (
                  <tr
                    key={prod.id}
                    onClick={() => {
                      setActiveProductId(prod.id);
                      setCurrentPage('intelligence');
                    }}
                    className="hover:bg-blue-50/40 transition-colors cursor-pointer"
                  >
                    {/* Name & Model */}
                    <td className="py-4 px-6">
                      <div className="font-bold text-slate-900 text-sm">{prod.name}</div>
                      <div className="font-mono text-slate-500 text-[11px]">{prod.modelNumber} • {prod.sku}</div>
                    </td>

                    {/* Category */}
                    <td className="py-4 px-6">
                      <span className="inline-block px-2.5 py-1 rounded-md bg-slate-100 text-slate-700 font-medium text-xs">
                        {prod.category}
                      </span>
                    </td>

                    {/* Manufacturer */}
                    <td className="py-4 px-6">
                      <span className="font-semibold text-slate-800">{prod.manufacturer}</span>
                    </td>

                    {/* Status */}
                    <td className="py-4 px-6">
                      {isConflicted ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                          <AlertTriangle className="w-3 h-3 text-rose-600" />
                          <span>CONFLICT DETECTED</span>
                        </span>
                      ) : isReady ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>READY FOR CATALOG</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                          NEEDS REVIEW
                        </span>
                      )}
                    </td>

                    {/* Trust Score */}
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-slate-100 h-2 rounded-full overflow-hidden">
                          <div
                            className={`h-full ${
                              prod.trustScore.overall >= 95
                                ? 'bg-emerald-500'
                                : prod.trustScore.overall >= 90
                                ? 'bg-blue-500'
                                : 'bg-amber-500'
                            }`}
                            style={{ width: `${prod.trustScore.overall}%` }}
                          />
                        </div>
                        <span className="font-mono font-bold text-slate-800 text-xs">
                          {prod.trustScore.overall}%
                        </span>
                      </div>
                    </td>

                    {/* Action */}
                    <td className="py-4 px-6 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setActiveProductId(prod.id);
                          setCurrentPage('intelligence');
                        }}
                        className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-blue-600 hover:text-white text-slate-700 font-semibold text-xs transition-colors cursor-pointer inline-flex items-center gap-1"
                      >
                        <span>Open Intelligence</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
