import React from 'react';
import { useApp } from '../context/AppContext';
import { Database, Search, ShieldCheck, AlertOctagon, Cpu, CheckCircle2 } from 'lucide-react';

export const ProcessingModal: React.FC = () => {
  const { isProcessingDemo, processingStep, processingMessage } = useApp();

  if (!isProcessingDemo) return null;

  const steps = [
    {
      id: 1,
      name: 'Multi-Source Document Ingestion',
      desc: 'Parsing Website HTML, Master Catalog PDF, and Engineering Datasheets',
      icon: Database,
    },
    {
      id: 2,
      name: 'Entity Extraction & Unit Normalization',
      desc: 'Harmonizing kW ↔ HP, Bar ↔ PSI, RPM, Enclosure IP codes, Voltage',
      icon: Cpu,
    },
    {
      id: 3,
      name: 'Cross-Source Provenance Cross-Check',
      desc: 'Comparing values across independent sources & computing source weights',
      icon: Search,
    },
    {
      id: 4,
      name: 'Conflict Detection & Trust Engine Scoring',
      desc: 'Flagging discrepancies, computing Trust Index & building provenance trail',
      icon: processingStep >= 4 ? AlertOctagon : ShieldCheck,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
      <div
        id="processing-pipeline-modal"
        className="w-full max-w-lg bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden p-6 sm:p-8"
      >
        <div className="flex items-center justify-between pb-5 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 animate-pulse">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">AI Intelligence Engine In Progress</h3>
              <p className="text-xs text-slate-500 font-mono">Pipeline Execution ID: #IQ-{Date.now().toString().slice(-6)}</p>
            </div>
          </div>
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">
            Step {processingStep} of 4
          </span>
        </div>

        {/* Live Message banner */}
        <div className="mt-5 p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-3">
          <div className="w-2.5 h-2.5 rounded-full bg-blue-600 animate-ping mt-1 shrink-0" />
          <p className="text-xs font-medium text-slate-700 leading-relaxed font-mono">
            {processingMessage || 'Running multi-modal attribute reconciliation...'}
          </p>
        </div>

        {/* Pipeline steps visualization */}
        <div className="mt-6 space-y-4">
          {steps.map((step) => {
            const isCompleted = processingStep > step.id;
            const isCurrent = processingStep === step.id;
            const isPending = processingStep < step.id;

            const Icon = step.icon;

            return (
              <div
                key={step.id}
                className={`flex items-start gap-3.5 p-3 rounded-xl transition-all duration-300 ${
                  isCurrent
                    ? 'bg-blue-50/70 border border-blue-200 shadow-sm'
                    : isCompleted
                    ? 'bg-slate-50/50 border border-slate-100'
                    : 'opacity-40 border border-transparent'
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 text-sm font-semibold transition-colors ${
                    isCompleted
                      ? 'bg-emerald-100 text-emerald-700'
                      : isCurrent
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-200'
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : <Icon className="w-4 h-4" />}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4
                      className={`text-xs font-bold ${
                        isCurrent ? 'text-blue-950' : isCompleted ? 'text-slate-900' : 'text-slate-500'
                      }`}
                    >
                      {step.name}
                    </h4>
                    {isCurrent && (
                      <span className="text-[10px] font-mono font-medium text-blue-600 bg-blue-100/70 px-2 py-0.5 rounded">
                        PROCESSING
                      </span>
                    )}
                    {isCompleted && (
                      <span className="text-[10px] font-mono font-medium text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded">
                        VERIFIED
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 leading-normal">{step.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Progress bar */}
        <div className="mt-6 pt-4 border-t border-slate-100">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5">
            <span className="font-medium">Synthesis Progress</span>
            <span className="font-mono font-bold text-slate-700">{processingStep * 25}%</span>
          </div>
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
            <div
              className="bg-blue-600 h-full transition-all duration-500 ease-out"
              style={{ width: `${processingStep * 25}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
