import React from 'react';
import { useApp } from '../context/AppContext';
import { PageId } from '../types';
import {
  Compass,
  LayoutDashboard,
  Sparkles,
  Cpu,
  FileCheck2,
  AlertTriangle,
  ShieldCheck,
  Package,
  Download,
  Settings,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const {
    currentPage,
    setCurrentPage,
    totalConflictsCount,
    readyForCatalogCount,
    totalProductsCount,
    activeProduct,
    launchDemoFlow,
  } = useApp();

  const navItems: { id: PageId; label: string; icon: React.ComponentType<{ className?: string }>; badge?: string | number; badgeColor?: string }[] = [
    { id: 'landing', label: 'Overview & Tour', icon: Compass },
    { id: 'dashboard', label: 'Executive Dashboard', icon: LayoutDashboard },
    { id: 'analyze', label: 'Analyze Product', icon: Sparkles },
    {
      id: 'intelligence',
      label: 'Product Intelligence',
      icon: Cpu,
      badge: activeProduct?.modelNumber || 'X500',
      badgeColor: 'bg-blue-100 text-blue-800',
    },
    { id: 'evidence', label: 'Evidence Center', icon: FileCheck2 },
    {
      id: 'conflicts',
      label: 'Review / Conflict Queue',
      icon: AlertTriangle,
      badge: totalConflictsCount > 0 ? totalConflictsCount : undefined,
      badgeColor: 'bg-rose-100 text-rose-800 font-bold border border-rose-200',
    },
    { id: 'trust', label: 'Trust Center', icon: ShieldCheck },
    {
      id: 'products',
      label: 'Products Catalog',
      icon: Package,
      badge: totalProductsCount,
      badgeColor: 'bg-slate-100 text-slate-700',
    },
    { id: 'exports', label: 'Data Syndication & Exports', icon: Download },
    { id: 'settings', label: 'Engine Settings', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col shrink-0 border-r border-slate-800 select-none">
      {/* Top section: System environment info */}
      <div className="p-4 border-b border-slate-800/80 bg-slate-950/40">
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-400 font-medium">Platform Mode</span>
          <span className="font-mono text-[11px] font-bold text-emerald-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            STANDALONE DEMO
          </span>
        </div>
        <div className="mt-2 text-[11px] text-slate-500 font-mono flex items-center justify-between">
          <span>Active Product:</span>
          <span className="text-slate-300 font-semibold truncate max-w-[120px]">
            {activeProduct?.name || 'X500 Motor'}
          </span>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 overflow-y-auto p-3 space-y-1">
        <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-300">
          Workspaces & Tools
        </div>

        {navItems.map((item) => {
          const isActive = currentPage === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              id={`sidebar-nav-${item.id}`}
              onClick={() => setCurrentPage(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all text-left cursor-pointer group ${
                isActive
                  ? 'bg-blue-600 text-white shadow-sm shadow-blue-600/30'
                  : 'text-slate-300 hover:bg-slate-800/70 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <Icon
                  className={`w-4 h-4 shrink-0 transition-colors ${
                    isActive ? 'text-white' : 'text-slate-300 group-hover:text-blue-300'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>

              {item.badge !== undefined && (
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-full shrink-0 ml-1 ${
                    isActive ? 'bg-blue-500 text-white' : item.badgeColor || 'bg-slate-800 text-slate-300'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Trust & Verification Quick Metric Card */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-950/60">
        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Active Trust Index
            </span>
            <span
              className={`text-xs font-mono font-black ${
                (activeProduct?.trustScore.overall || 0) >= 95
                  ? 'text-emerald-400'
                  : (activeProduct?.trustScore.overall || 0) >= 90
                  ? 'text-blue-400'
                  : 'text-amber-400'
              }`}
            >
              {activeProduct?.trustScore.overall || 0}%
            </span>
          </div>

          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-2">
            <div
              className={`h-full transition-all duration-500 ${
                (activeProduct?.trustScore.overall || 0) >= 95
                  ? 'bg-emerald-500'
                  : (activeProduct?.trustScore.overall || 0) >= 90
                  ? 'bg-blue-500'
                  : 'bg-amber-500'
              }`}
              style={{ width: `${activeProduct?.trustScore.overall || 0}%` }}
            />
          </div>

          <div className="mt-2.5 flex items-center justify-between text-[10px] text-slate-400">
            <span>Status:</span>
            <span
              className={`font-semibold ${
                activeProduct?.status === 'READY_FOR_CATALOG'
                  ? 'text-emerald-400'
                  : 'text-rose-400'
              }`}
            >
              {activeProduct?.status === 'READY_FOR_CATALOG' ? 'READY FOR CATALOG' : 'CONFLICT DETECTED'}
            </span>
          </div>
        </div>

        {/* 1-Click Interactive Demo button at sidebar bottom */}
        <button
          onClick={launchDemoFlow}
          className="mt-3 w-full py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer border border-slate-700/60"
        >
          <span>Run X500 Flow</span>
          <ArrowRight className="w-3.5 h-3.5 text-blue-400" />
        </button>
      </div>
    </aside>
  );
};
