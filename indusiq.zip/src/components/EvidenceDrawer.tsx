import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  ShieldCheck,
  AlertTriangle,
  FileText,
  Globe,
  BookOpen,
  Sparkles,
  CheckCircle2,
  ExternalLink,
  ArrowRight,
  HelpCircle,
} from 'lucide-react';

export const EvidenceDrawer: React.FC = () => {
  const {
    isEvidenceDrawerOpen,
    closeEvidenceDrawer,
    activeProduct,
    selectedAttributeKey,
    resolveConflict,
    imputeMissingField,
  } = useApp();

  const [selectedValue, setSelectedValue] = useState<string>('');
  const [resolutionReason, setResolutionReason] = useState<string>('');
  const [customValueInput, setCustomValueInput] = useState<string>('');
  const [isCustomMode, setIsCustomMode] = useState(false);

  const attribute =
    activeProduct && selectedAttributeKey
      ? activeProduct.attributes[selectedAttributeKey]
      : null;

  const conflict =
    activeProduct && selectedAttributeKey
      ? activeProduct.conflicts.find((c) => c.attributeKey === selectedAttributeKey)
      : null;

  // Sync default selection when opening
  useEffect(() => {
    if (conflict && conflict.conflictingValues.length > 0) {
      const rec = conflict.conflictingValues.find((v) => v.recommended) || conflict.conflictingValues[0];
      setSelectedValue(rec.value);
      setResolutionReason(
        rec.reasoning ||
          'Datasheet Rev 2.4 represents the verified engineering specification with Class H winding upgrade.'
      );
      setIsCustomMode(false);
    } else if (attribute && attribute.suggestedValue) {
      setSelectedValue(attribute.suggestedValue);
      setResolutionReason(attribute.suggestedReason || 'Derived from standard industrial baselines.');
    }
  }, [selectedAttributeKey, activeProduct, conflict, attribute]);

  if (!isEvidenceDrawerOpen || !activeProduct || !attribute) {
    return null;
  }

  const handleResolve = () => {
    const finalVal = isCustomMode ? customValueInput : selectedValue;
    if (!finalVal) return;

    if (conflict) {
      resolveConflict(activeProduct.id, attribute.key, finalVal, resolutionReason);
    } else if (attribute.isMissing) {
      imputeMissingField(activeProduct.id, attribute.key, finalVal);
      closeEvidenceDrawer();
    }
  };

  const getSourceIcon = (type: string) => {
    switch (type) {
      case 'website':
        return <Globe className="w-4 h-4 text-sky-600" />;
      case 'catalog':
        return <BookOpen className="w-4 h-4 text-indigo-600" />;
      case 'datasheet':
        return <FileText className="w-4 h-4 text-emerald-600" />;
      default:
        return <FileText className="w-4 h-4 text-slate-600" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/50 backdrop-blur-xs flex justify-end">
      <div
        id="evidence-provenance-drawer"
        className="w-full max-w-2xl bg-white h-full shadow-2xl flex flex-col border-l border-slate-200 animate-in slide-in-from-right duration-250 ease-out"
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-semibold uppercase text-slate-500 tracking-wider">
                Provenance & Evidence Inspector
              </span>
              {attribute.isConflicted && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                  <AlertTriangle className="w-3 h-3" /> Multi-Source Conflict
                </span>
              )}
              {attribute.isMissing && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                  Missing Field Imputation
                </span>
              )}
            </div>
            <h2 className="text-xl font-bold text-slate-900 mt-1 flex items-center gap-2">
              {attribute.name}
              <span className="text-xs font-normal text-slate-500 font-mono">
                ({attribute.standardNormalizedKey || attribute.key})
              </span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Product: <span className="font-medium text-slate-700">{activeProduct.name}</span> ({activeProduct.modelNumber})
            </p>
          </div>

          <button
            onClick={closeEvidenceDrawer}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-lg transition-colors"
            aria-label="Close drawer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Conflict Resolution Block */}
          {conflict && !conflict.isResolved && (
            <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-amber-950">Discrepancy Detected Across Ingested Sources</h4>
                  <p className="text-xs text-amber-900/90 mt-1 leading-relaxed">
                    Website and legacy catalog state <strong>5 HP</strong>, while Engineering Datasheet Rev 2.4 specifies <strong>7.5 HP</strong>.
                    Review source evidence below and select the verified specification.
                  </p>
                </div>
              </div>

              {/* Multi-source Option Cards */}
              <div className="mt-4 space-y-2.5">
                {conflict.conflictingValues.map((opt, idx) => {
                  const isSelected = !isCustomMode && selectedValue === opt.value;

                  return (
                    <div
                      key={idx}
                      onClick={() => {
                        setIsCustomMode(false);
                        setSelectedValue(opt.value);
                        if (opt.reasoning) setResolutionReason(opt.reasoning);
                      }}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'border-blue-600 bg-white ring-2 ring-blue-500/20 shadow-sm'
                          : 'border-slate-200 bg-white/80 hover:border-slate-300 hover:bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <input
                            type="radio"
                            checked={isSelected}
                            onChange={() => {}}
                            className="text-blue-600 focus:ring-blue-500 w-4 h-4"
                          />
                          <span className="text-base font-bold text-slate-900">{opt.value}</span>
                          {opt.recommended && (
                            <span className="inline-flex items-center gap-1 text-[11px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full border border-emerald-200">
                              <Sparkles className="w-3 h-3 text-emerald-600" /> Recommended by AI Engine
                            </span>
                          )}
                        </div>
                        <span className="text-xs font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                          Confidence: {opt.confidence}%
                        </span>
                      </div>

                      <div className="mt-2 text-xs text-slate-600 flex items-center gap-2">
                        <span className="font-medium text-slate-800">{opt.sourceName}</span>
                        <span className="text-slate-400">•</span>
                        <span className="capitalize text-slate-500">{opt.sourceType} Source</span>
                      </div>

                      {opt.reasoning && (
                        <p className="mt-2 text-xs text-slate-600 bg-slate-50 p-2 rounded-lg border border-slate-100 italic">
                          💡 {opt.reasoning}
                        </p>
                      )}
                    </div>
                  );
                })}

                {/* Custom override button */}
                <div
                  onClick={() => setIsCustomMode(true)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                    isCustomMode
                      ? 'border-blue-600 bg-white ring-2 ring-blue-500/20 shadow-sm'
                      : 'border-slate-200 bg-white/80 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <input
                      type="radio"
                      checked={isCustomMode}
                      onChange={() => {}}
                      className="text-blue-600 focus:ring-blue-500 w-4 h-4"
                    />
                    <span className="text-xs font-bold text-slate-800">Custom Engineering Override</span>
                  </div>

                  {isCustomMode && (
                    <div className="mt-3 space-y-2">
                      <input
                        type="text"
                        placeholder="Enter verified specification (e.g. 7.5 HP / 5.5 kW)"
                        value={customValueInput}
                        onChange={(e) => setCustomValueInput(e.target.value)}
                        className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 bg-white"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Resolution Rationale input */}
              <div className="mt-4 pt-3 border-t border-amber-200/60">
                <label className="block text-xs font-semibold text-slate-800 mb-1.5">
                  Audit Log Justification (Required for Trust Ledger)
                </label>
                <textarea
                  rows={2}
                  value={resolutionReason}
                  onChange={(e) => setResolutionReason(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 bg-white text-slate-800"
                  placeholder="State technical justification..."
                />
              </div>

              <div className="mt-4 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={handleResolve}
                  id="confirm-conflict-resolution-btn"
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 transition-all cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" /> Confirm & Resolve Conflict
                </button>
              </div>
            </div>
          )}

          {/* Missing Field AI Imputation Block */}
          {attribute.isMissing && (
            <div className="p-4 rounded-xl bg-blue-50/80 border border-blue-200">
              <div className="flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-blue-950">AI Baseline Imputation Available</h4>
                  <p className="text-xs text-blue-900/80 mt-1 leading-relaxed">
                    This attribute was not explicitly stated in ingested files. INDUSIQ can derive it from standard IEC/ISO technical baselines.
                  </p>
                </div>
              </div>

              <div className="mt-3 p-3 bg-white rounded-lg border border-blue-100">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-700">Suggested Standard Value:</span>
                  <span className="text-xs font-bold text-blue-700 font-mono bg-blue-50 px-2 py-0.5 rounded">
                    {attribute.suggestedValue}
                  </span>
                </div>
                {attribute.suggestedReason && (
                  <p className="text-xs text-slate-500 mt-2 italic leading-relaxed">
                    {attribute.suggestedReason}
                  </p>
                )}
              </div>

              <div className="mt-3 flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    if (attribute.suggestedValue) {
                      imputeMissingField(activeProduct.id, attribute.key, attribute.suggestedValue);
                      closeEvidenceDrawer();
                    }
                  }}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" /> Accept Standard Imputation
                </button>
              </div>
            </div>
          )}

          {/* Detailed Ingested Evidence Passages */}
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center justify-between mb-3">
              <span>Ingested Source Snippets & Provenance</span>
              <span className="text-xs font-normal text-slate-500">
                {attribute.sources.length} matching document references
              </span>
            </h3>

            {attribute.sources.length === 0 ? (
              <div className="p-6 text-center border border-dashed border-slate-200 rounded-xl bg-slate-50 text-slate-400">
                <HelpCircle className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-xs font-medium">No direct document mentions extracted for this attribute.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {attribute.sources.map((src, i) => (
                  <div
                    key={i}
                    className="p-4 rounded-xl border border-slate-200 bg-white hover:border-slate-300 transition-colors shadow-xs"
                  >
                    <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                      <div className="flex items-center gap-2">
                        {getSourceIcon(src.sourceType)}
                        <span className="text-xs font-bold text-slate-900">{src.sourceName}</span>
                        {src.pageOrSection && (
                          <span className="text-[11px] font-mono text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                            {src.pageOrSection}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-mono font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                          {src.confidence}% Match
                        </span>
                        <span className="text-[11px] font-mono text-slate-400">
                          Reliability: {src.reliabilityScore}%
                        </span>
                      </div>
                    </div>

                    <div className="mt-2.5">
                      <p className="text-xs text-slate-700 font-mono bg-slate-50 p-2.5 rounded-lg border border-slate-100 leading-relaxed">
                        "{src.snippet}"
                      </p>
                    </div>

                    <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
                      <span>Extracted value: <strong className="text-slate-800">{src.extractedValue}</strong></span>
                      <span>Verified: {src.timestamp}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Standards & Normalization Schema Box */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
              Ontology & Normalization Rule
            </h4>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-slate-400 block">Standard Dictionary Key:</span>
                <span className="font-mono font-semibold text-slate-800">
                  {attribute.standardNormalizedKey || 'GENERIC_ATTR'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Attribute Category:</span>
                <span className="font-medium text-slate-800 capitalize">{attribute.category}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 px-6 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <span className="text-xs text-slate-500 font-mono">
            INDUSIQ Immutable Audit Trail Active
          </span>
          <button
            onClick={closeEvidenceDrawer}
            className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors cursor-pointer"
          >
            Close Inspector
          </button>
        </div>
      </div>
    </div>
  );
};
