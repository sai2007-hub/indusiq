import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Zap,
  RotateCcw,
  ShieldCheck,
  Cpu,
  Layers,
  ChevronDown,
  Sparkles,
} from 'lucide-react';
import { PageId } from '../types';

export const Navbar: React.FC = () => {
  const {
    products,
    activeProduct,
    setActiveProductId,
    launchDemoFlow,
    resetDemoData,
    setCurrentPage,
    totalConflictsCount,
  } = useApp();

  return (
    <header className="h-16 bg-white border-b border-slate-200 sticky top-0 z-40 px-4 lg:px-6 flex items-center justify-between shadow-xs">
      {/* Brand logo & tagline */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => setCurrentPage('landing')}
          className="flex items-center gap-2.5 text-left group cursor-pointer focus:outline-none"
        >
          <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black tracking-wider text-base shadow-sm shadow-blue-500/30 group-hover:bg-blue-700 transition-colors">
            IQ
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-slate-900 tracking-tight text-base font-mono">
                INDUS<span className="text-blue-600">IQ</span>
              </span>
              <span className="hidden sm:inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-100 text-slate-700 border border-slate-200">
                v2.4
              </span>
            </div>
            <p className="hidden md:block text-[11px] text-slate-500 font-medium leading-none">
              AI Product Intelligence & Trust Engine
            </p>
          </div>
        </button>
      </div>

      {/* Center: Active Product Quick Selector */}
      <div className="hidden lg:flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5">
        <span className="text-xs text-slate-400 font-medium">Active Asset:</span>
        <select
          value={activeProduct?.id || ''}
          onChange={(e) => setActiveProductId(e.target.value)}
          className="bg-transparent text-xs font-bold text-slate-800 focus:outline-none cursor-pointer pr-2"
        >
          {products.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name} ({p.manufacturer}) — Trust: {p.trustScore.overall}%
            </option>
          ))}
        </select>
        {activeProduct?.status === 'CONFLICT_DETECTED' ? (
          <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
        ) : (
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
        )}
      </div>

      {/* Right Actions: Demo Mode indicator, Reset, and Launch Demo Button */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Demo Mode Badge */}
        <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold">
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          <span>Demo Mode Active</span>
        </div>

        {/* Reset Demo Data Button */}
        <button
          onClick={resetDemoData}
          title="Reset sample data back to initial conflicted state"
          className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors border border-transparent hover:border-slate-200 cursor-pointer"
          aria-label="Reset demo"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        {/* The Core Launch Demo CTA Button */}
        <button
          id="nav-launch-demo-btn"
          onClick={launchDemoFlow}
          className="inline-flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-98 text-white text-xs sm:text-sm font-bold shadow-md shadow-blue-500/25 transition-all cursor-pointer"
        >
          <Zap className="w-4 h-4 fill-white" />
          <span>Launch Demo</span>
        </button>
      </div>
    </header>
  );
};
