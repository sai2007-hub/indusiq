import { ProductAttribute, AttributeConflict, TrustScoreBreakdown, TrustWeights } from '../types';

export const DEFAULT_TRUST_WEIGHTS: TrustWeights = {
  completenessWeight: 0.25,
  consistencyWeight: 0.40,
  sourceQualityWeight: 0.20,
  confidenceWeight: 0.15,
};

export function calculateTrustScore(
  attributes: Record<string, ProductAttribute>,
  conflicts: AttributeConflict[],
  weights: TrustWeights = DEFAULT_TRUST_WEIGHTS
): TrustScoreBreakdown {
  const attrList = Object.values(attributes);
  const totalAttrs = attrList.length;

  if (totalAttrs === 0) {
    return {
      overall: 0,
      completeness: 0,
      consistency: 0,
      sourceQuality: 0,
      extractionConfidence: 0,
      formulaExplanation: 'No attributes available to evaluate.',
    };
  }

  // 1. Completeness: % of non-missing attributes
  const presentCount = attrList.filter((a) => !a.isMissing && a.value !== null && a.value.trim() !== '').length;
  const completeness = Math.round((presentCount / totalAttrs) * 100);

  // 2. Consistency: % of attributes without active unresolved conflicts
  const activeConflicts = conflicts.filter((c) => !c.isResolved);
  const conflictedCount = activeConflicts.length;
  const consistency = Math.max(0, Math.round(((totalAttrs - conflictedCount * 1.5) / totalAttrs) * 100));

  // 3. Source Quality: Weighted average of source reliability
  let totalSourcesScore = 0;
  let totalSourcesCount = 0;
  attrList.forEach((attr) => {
    attr.sources.forEach((s) => {
      totalSourcesScore += s.reliabilityScore;
      totalSourcesCount++;
    });
  });
  const sourceQuality = totalSourcesCount > 0 ? Math.round(totalSourcesScore / totalSourcesCount) : 90;

  // 4. Extraction Confidence: Average confidence across all extracted attributes
  let totalConf = 0;
  let countWithConf = 0;
  attrList.forEach((attr) => {
    if (!attr.isMissing) {
      totalConf += attr.confidence;
      countWithConf++;
    }
  });
  const extractionConfidence = countWithConf > 0 ? Math.round(totalConf / countWithConf) : 92;

  // Normalized weight sum check
  const wSum =
    weights.completenessWeight +
    weights.consistencyWeight +
    weights.sourceQualityWeight +
    weights.confidenceWeight;

  const rawOverall =
    (completeness * weights.completenessWeight +
      consistency * weights.consistencyWeight +
      sourceQuality * weights.sourceQualityWeight +
      extractionConfidence * weights.confidenceWeight) /
    wSum;

  const overall = Math.min(100, Math.max(0, Math.round(rawOverall)));

  const formulaExplanation = `Trust Score = (${weights.completenessWeight} × Completeness [${completeness}%]) + (${weights.consistencyWeight} × Consistency [${consistency}%]) + (${weights.sourceQualityWeight} × Source Quality [${sourceQuality}%]) + (${weights.confidenceWeight} × Confidence [${extractionConfidence}%])`;

  return {
    overall,
    completeness,
    consistency,
    sourceQuality,
    extractionConfidence,
    formulaExplanation,
  };
}
