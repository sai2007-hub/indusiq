import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  PageId,
  ProductItem,
  TrustWeights,
  AttributeConflict,
  ProductAttribute,
  TrustScoreBreakdown,
} from '../types';
import { INITIAL_PRODUCTS } from '../data/mockData';
import { DEFAULT_TRUST_WEIGHTS, calculateTrustScore } from '../utils/trustScore';

export interface ToastMessage {
  id: string;
  title: string;
  description: string;
  type: 'success' | 'warning' | 'error' | 'info';
}

interface AppContextType {
  currentPage: PageId;
  setCurrentPage: (page: PageId) => void;
  products: ProductItem[];
  activeProduct: ProductItem | null;
  setActiveProductId: (id: string) => void;
  trustWeights: TrustWeights;
  setTrustWeights: (weights: TrustWeights) => void;
  // Conflict & Evidence Drawer
  isEvidenceDrawerOpen: boolean;
  selectedAttributeKey: string | null;
  openEvidenceDrawer: (attributeKey: string) => void;
  closeEvidenceDrawer: () => void;
  resolveConflict: (
    productId: string,
    attributeKey: string,
    selectedValue: string,
    reason: string
  ) => void;
  imputeMissingField: (
    productId: string,
    attributeKey: string,
    acceptedValue: string
  ) => void;
  // Demo processing flow
  isProcessingDemo: boolean;
  processingStep: number;
  processingMessage: string;
  launchDemoFlow: () => void;
  resetDemoData: () => void;
  // New Product Analysis
  analyzeNewProduct: (
    productName: string,
    category: string,
    manufacturer: string,
    websiteText: string,
    catalogText: string,
    datasheetText: string
  ) => Promise<void>;
  // Toasts
  toasts: ToastMessage[];
  addToast: (title: string, description: string, type?: ToastMessage['type']) => void;
  removeToast: (id: string) => void;
  // Quick stats
  totalProductsCount: number;
  totalConflictsCount: number;
  readyForCatalogCount: number;
  averageTrustScore: number;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentPage, setCurrentPage] = useState<PageId>('landing');
  const [products, setProducts] = useState<ProductItem[]>(INITIAL_PRODUCTS);
  const [activeProductId, setActiveProductIdState] = useState<string>('prod-x500');
  const [trustWeights, setTrustWeights] = useState<TrustWeights>(DEFAULT_TRUST_WEIGHTS);

  // Evidence Drawer state
  const [isEvidenceDrawerOpen, setIsEvidenceDrawerOpen] = useState(false);
  const [selectedAttributeKey, setSelectedAttributeKey] = useState<string | null>(null);

  // Demo processing animation state
  const [isProcessingDemo, setIsProcessingDemo] = useState(false);
  const [processingStep, setProcessingStep] = useState(0);
  const [processingMessage, setProcessingMessage] = useState('');

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (title: string, description: string, type: ToastMessage['type'] = 'info') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    setToasts((prev) => [...prev, { id, title, description, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const activeProduct = useMemo(() => {
    return products.find((p) => p.id === activeProductId) || products[0] || null;
  }, [products, activeProductId]);

  const setActiveProductId = (id: string) => {
    setActiveProductIdState(id);
  };

  const openEvidenceDrawer = (attributeKey: string) => {
    setSelectedAttributeKey(attributeKey);
    setIsEvidenceDrawerOpen(true);
  };

  const closeEvidenceDrawer = () => {
    setIsEvidenceDrawerOpen(false);
    setSelectedAttributeKey(null);
  };

  // Resolve conflict logic
  const resolveConflict = (
    productId: string,
    attributeKey: string,
    selectedValue: string,
    reason: string
  ) => {
    setProducts((prev) =>
      prev.map((prod) => {
        if (prod.id !== productId) return prod;

        // Update conflicts
        const updatedConflicts = prod.conflicts.map((conf) => {
          if (conf.attributeKey === attributeKey) {
            return {
              ...conf,
              isResolved: true,
              resolvedValue: selectedValue,
              resolutionReason: reason,
              resolvedBy: 'Lead Technical Reviewer',
              resolvedAt: new Date().toISOString(),
            };
          }
          return conf;
        });

        // Update attribute
        const currentAttr = prod.attributes[attributeKey];
        if (!currentAttr) return prod;

        const updatedAttr: ProductAttribute = {
          ...currentAttr,
          value: selectedValue,
          isConflicted: false,
          confidence: 99,
        };

        const updatedAttributes = {
          ...prod.attributes,
          [attributeKey]: updatedAttr,
        };

        // Recalculate Trust Score
        const newTrustBreakdown = calculateTrustScore(
          updatedAttributes,
          updatedConflicts,
          trustWeights
        );

        // Check if any active conflicts left
        const remainingActiveConflicts = updatedConflicts.filter((c) => !c.isResolved);
        const newStatus = remainingActiveConflicts.length === 0 ? 'READY_FOR_CATALOG' : prod.status;

        // Add audit history
        const newAudit = {
          id: `aud-${Date.now()}`,
          timestamp: new Date().toISOString(),
          action: 'CONFLICT_RESOLVED',
          user: 'Human Reviewer (Verified)',
          details: `Resolved [${currentAttr.name}] conflict to '${selectedValue}'. Reason: ${reason}`,
        };

        return {
          ...prod,
          status: newStatus,
          trustScore: {
            ...newTrustBreakdown,
            // Guaranteed 96% for X500 as required in demo specification
            overall: prod.id === 'prod-x500' ? 96 : newTrustBreakdown.overall,
          },
          attributes: updatedAttributes,
          conflicts: updatedConflicts,
          auditHistory: [newAudit, ...prod.auditHistory],
          lastUpdated: new Date().toISOString(),
        };
      })
    );

    closeEvidenceDrawer();
    addToast(
      'Conflict Resolved Successfully',
      `Power specification confirmed as ${selectedValue}. Trust Score updated to 96% and product marked as READY FOR CATALOG.`,
      'success'
    );
  };

  // Impute missing field logic
  const imputeMissingField = (
    productId: string,
    attributeKey: string,
    acceptedValue: string
  ) => {
    setProducts((prev) =>
      prev.map((prod) => {
        if (prod.id !== productId) return prod;

        const currentAttr = prod.attributes[attributeKey];
        if (!currentAttr) return prod;

        const updatedAttr: ProductAttribute = {
          ...currentAttr,
          value: acceptedValue,
          isMissing: false,
          confidence: 94,
        };

        const updatedAttributes = {
          ...prod.attributes,
          [attributeKey]: updatedAttr,
        };

        const newTrustBreakdown = calculateTrustScore(
          updatedAttributes,
          prod.conflicts,
          trustWeights
        );

        const newAudit = {
          id: `aud-${Date.now()}`,
          timestamp: new Date().toISOString(),
          action: 'MISSING_FIELD_IMPUTED',
          user: 'AI Standard Rule Engine',
          details: `Imputed missing [${currentAttr.name}] with value '${acceptedValue}' derived from IEC/NEMA baseline standard.`,
        };

        return {
          ...prod,
          trustScore: {
            ...newTrustBreakdown,
            overall: Math.min(100, prod.trustScore.overall + 2),
            completeness: 100,
          },
          attributes: updatedAttributes,
          auditHistory: [newAudit, ...prod.auditHistory],
        };
      })
    );

    addToast(
      'Attribute Standardized',
      `Energy Efficiency Class imputed with ${acceptedValue}. Completeness score increased to 100%.`,
      'info'
    );
  };

  // Launch Core Demo Flow
  const launchDemoFlow = () => {
    // Reset X500 to initial conflicted state
    setProducts(INITIAL_PRODUCTS);
    setActiveProductIdState('prod-x500');
    setIsProcessingDemo(true);
    setProcessingStep(1);
    setProcessingMessage('Ingesting multi-source industrial documents (Website, Catalog, Datasheet)...');

    setTimeout(() => {
      setProcessingStep(2);
      setProcessingMessage('Extracting technical specifications & normalizing units...');
    }, 800);

    setTimeout(() => {
      setProcessingStep(3);
      setProcessingMessage('Cross-referencing claims across sources & computing reliability weights...');
    }, 1600);

    setTimeout(() => {
      setProcessingStep(4);
      setProcessingMessage('⚠ Conflict detected on [Power Rating] (5 HP vs 7.5 HP) | Computing Trust Score (92%)...');
    }, 2400);

    setTimeout(() => {
      setIsProcessingDemo(false);
      setCurrentPage('intelligence');
      addToast(
        'Product Intelligence Ready',
        'X500 Industrial Motor parsed with 92% Trust Score. 1 specification conflict requires human verification.',
        'warning'
      );
    }, 3200);
  };

  const resetDemoData = () => {
    setProducts(INITIAL_PRODUCTS);
    setActiveProductIdState('prod-x500');
    addToast('Demo State Reset', 'Restored default X500 Motor with 5 HP vs 7.5 HP power conflict.', 'info');
  };

  // Analyze arbitrary new product
  const analyzeNewProduct = async (
    productName: string,
    category: string,
    manufacturer: string,
    websiteText: string,
    catalogText: string,
    datasheetText: string
  ) => {
    setIsProcessingDemo(true);
    setProcessingStep(1);
    setProcessingMessage(`Ingesting source documents for ${productName}...`);

    await new Promise((r) => setTimeout(r, 700));
    setProcessingStep(2);
    setProcessingMessage('Parsing entity attributes, standardizing units (kW, HP, Bar, RPM)...');

    await new Promise((r) => setTimeout(r, 800));
    setProcessingStep(3);
    setProcessingMessage('Synthesizing cross-source evidence matrix & checking for contradictions...');

    await new Promise((r) => setTimeout(r, 700));
    setProcessingStep(4);
    setProcessingMessage('Finalizing Trust Score and generating provenance audit graph...');

    await new Promise((r) => setTimeout(r, 600));

    const newId = `prod-${Date.now()}`;
    const newProduct: ProductItem = {
      id: newId,
      name: productName || 'Custom Industrial Assembly',
      modelNumber: `MOD-${Math.floor(1000 + Math.random() * 9000)}`,
      sku: `SKU-${Math.floor(10000 + Math.random() * 90000)}`,
      category: category || 'Industrial Equipment',
      manufacturer: manufacturer || 'Industrial OEM',
      status: 'READY_FOR_CATALOG',
      catalogCategoryPath: ['General Industrial', category || 'Assemblies'],
      complianceStandards: ['ISO 9001', 'CE Certified'],
      lastUpdated: new Date().toISOString(),
      trustScore: {
        overall: 95,
        completeness: 92,
        consistency: 98,
        sourceQuality: 94,
        extractionConfidence: 96,
        formulaExplanation: 'Cross-source analysis completed with high provenance agreement.',
      },
      rawSources: [
        {
          id: `src-web-${newId}`,
          type: 'website',
          title: 'Product Landing Page',
          fileNameOrUrl: 'https://oem-portal.com/product/custom',
          uploadDate: new Date().toISOString().split('T')[0],
          contentSnippet: websiteText.slice(0, 150) || 'Official manufacturer product specifications and parameters.',
          reliabilityWeight: 0.85,
          attributeCountExtracted: 4,
        },
        {
          id: `src-cat-${newId}`,
          type: 'catalog',
          title: 'Master Catalog Entry',
          fileNameOrUrl: 'OEM_Catalog_Export.pdf',
          uploadDate: new Date().toISOString().split('T')[0],
          contentSnippet: catalogText.slice(0, 150) || 'Catalog listing with dimensional and electrical ratings.',
          reliabilityWeight: 0.90,
          attributeCountExtracted: 5,
        },
        {
          id: `src-data-${newId}`,
          type: 'datasheet',
          title: 'Certified Engineering Datasheet',
          fileNameOrUrl: 'Engineering_Specification_Sheet.pdf',
          uploadDate: new Date().toISOString().split('T')[0],
          contentSnippet: datasheetText.slice(0, 150) || 'Certified technical tolerances, test bench results, and certifications.',
          reliabilityWeight: 0.98,
          attributeCountExtracted: 6,
        },
      ],
      conflicts: [],
      attributes: {
        power: {
          key: 'power',
          name: 'Rated Output Power',
          value: '10 kW / 13.4 HP',
          unit: 'kW',
          isMissing: false,
          isConflicted: false,
          confidence: 97,
          category: 'electrical',
          sources: [
            {
              sourceId: `src-data-${newId}`,
              sourceType: 'datasheet',
              sourceName: 'Engineering Specification',
              sourceUri: 'Engineering_Specification_Sheet.pdf',
              timestamp: new Date().toISOString().split('T')[0],
              extractedValue: '10 kW',
              confidence: 98,
              snippet: 'Rated continuous output power: 10 kW',
              reliabilityScore: 98,
            },
          ],
        },
        voltage: {
          key: 'voltage',
          name: 'Operating Voltage',
          value: '400 V AC',
          unit: 'V',
          isMissing: false,
          isConflicted: false,
          confidence: 98,
          category: 'electrical',
          sources: [],
        },
        frequency: {
          key: 'frequency',
          name: 'Supply Frequency',
          value: '50/60 Hz Dual',
          unit: 'Hz',
          isMissing: false,
          isConflicted: false,
          confidence: 96,
          category: 'electrical',
          sources: [],
        },
        housing: {
          key: 'housing',
          name: 'Enclosure Material',
          value: 'Die-Cast Aluminum / IP66',
          unit: '',
          isMissing: false,
          isConflicted: false,
          confidence: 95,
          category: 'environmental',
          sources: [],
        },
      },
      auditHistory: [
        {
          id: `aud-${Date.now()}`,
          timestamp: new Date().toISOString(),
          action: 'CUSTOM_EXTRACTION_SUCCESS',
          user: 'INDUSIQ Auto-Ingest Engine',
          details: 'Processed 3 uploaded text sources. Extracted and normalized 4 key specifications.',
        },
      ],
    };

    setProducts((prev) => [newProduct, ...prev]);
    setActiveProductIdState(newId);
    setIsProcessingDemo(false);
    setCurrentPage('intelligence');
    addToast('Extraction Complete', `${newProduct.name} analyzed with 95% Trust Score.`, 'success');
  };

  // Aggregate stats
  const totalProductsCount = products.length;
  const totalConflictsCount = products.reduce(
    (acc, p) => acc + p.conflicts.filter((c) => !c.isResolved).length,
    0
  );
  const readyForCatalogCount = products.filter((p) => p.status === 'READY_FOR_CATALOG').length;
  const averageTrustScore =
    products.length > 0
      ? Math.round(products.reduce((acc, p) => acc + p.trustScore.overall, 0) / products.length)
      : 0;

  return (
    <AppContext.Provider
      value={{
        currentPage,
        setCurrentPage,
        products,
        activeProduct,
        setActiveProductId,
        trustWeights,
        setTrustWeights,
        isEvidenceDrawerOpen,
        selectedAttributeKey,
        openEvidenceDrawer,
        closeEvidenceDrawer,
        resolveConflict,
        imputeMissingField,
        isProcessingDemo,
        processingStep,
        processingMessage,
        launchDemoFlow,
        resetDemoData,
        analyzeNewProduct,
        toasts,
        addToast,
        removeToast,
        totalProductsCount,
        totalConflictsCount,
        readyForCatalogCount,
        averageTrustScore,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
